class Coordenada {
  late double latitud;
  late double longitud;

  Coordenada({
    required this.latitud,
    required this.longitud,
  });
}
