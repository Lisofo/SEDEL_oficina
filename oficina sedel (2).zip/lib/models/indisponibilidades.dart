import 'dart:convert';

import 'cliente.dart';
import 'tecnico.dart';

List<Indisponibilidad> indisponibilidadFromMap(String str) =>
    List<Indisponibilidad>.from(
        json.decode(str).map((x) => Indisponibilidad.fromJson(x)));

String indisponibilidadToMap(List<Indisponibilidad> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toMap())));

class Indisponibilidad {
  late int indisponibilidadId;
  late DateTime desde;
  late DateTime hasta;
  late String comentario;
  late TipoIndisponibilidad tipoIndisponibilidad;
  late Cliente? cliente;
  late Tecnico? tecnico;
  

  Indisponibilidad({
    required this.indisponibilidadId,
    required this.desde,
    required this.hasta,
    required this.comentario,
    required this.tipoIndisponibilidad,
    this.cliente,
    this.tecnico,
  });

  factory Indisponibilidad.fromJson(Map<String, dynamic> json) =>
      Indisponibilidad(
        indisponibilidadId: json["indisponibilidadId"],
        desde: DateTime.parse(json["desde"]),
        hasta: DateTime.parse(json["hasta"]),
        comentario: json["comentario"],
        tipoIndisponibilidad:
            TipoIndisponibilidad.fromJson(json["tipoIndisponibilidad"]),
        cliente: json["cliente"] == null
            ? Cliente.empty()
            : Cliente.fromJson(json["cliente"]),
        tecnico: json["tecnico"] == null
            ? Tecnico.empty()
            : Tecnico.fromJson(json["tecnico"]),
      );

  Map<String, dynamic> toMap() => {
        "indisponibilidadId": indisponibilidadId,
        "desde": desde.toIso8601String(),
        "hasta": hasta.toIso8601String(),
        "comentario": comentario,
        "tipoIndisponibilidad": tipoIndisponibilidad.toMap(),
        "cliente": cliente?.toMap(),
        "tecnico": tecnico?.toMap(),
      };
      Indisponibilidad.empty(){}
}

class TipoIndisponibilidad {
  int tipoIndisponibilidadId;
  String codTipoIndisponibilidad;
  String descripcion;

  TipoIndisponibilidad({
    required this.tipoIndisponibilidadId,
    required this.codTipoIndisponibilidad,
    required this.descripcion,
  });

  factory TipoIndisponibilidad.fromJson(Map<String, dynamic> json) =>
      TipoIndisponibilidad(
        tipoIndisponibilidadId: json["tipoIndisponibilidadId"],
        codTipoIndisponibilidad: json["codTipoIndisponibilidad"],
        descripcion: json["descripcion"],
      );

  Map<String, dynamic> toMap() => {
        "tipoIndisponibilidadId": tipoIndisponibilidadId,
        "codTipoIndisponibilidad": codTipoIndisponibilidad,
        "descripcion": descripcion,
      };
}
