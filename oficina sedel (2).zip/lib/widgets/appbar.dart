// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';

class AppBarDesign extends StatefulWidget implements PreferredSizeWidget {
  late String titulo;

  AppBarDesign({required this.titulo});

  @override
  State<AppBarDesign> createState() => _AppBarDesignState();

  @override
  Size get preferredSize => Size.fromHeight(AppBar().preferredSize.height);
}

class _AppBarDesignState extends State<AppBarDesign> {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Color.fromARGB(255, 52, 120, 62),
      title: Text(
        widget.titulo,
        style: TextStyle(color: Colors.white),
      ),
      actions: [
        IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back_ios_new,
              color: Colors.white,
            ))
      ],
    );
  }
}
