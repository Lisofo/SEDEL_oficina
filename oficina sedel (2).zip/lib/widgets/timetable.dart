import 'package:flutter/material.dart';
import 'package:flutter_timetable/flutter_timetable.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/models/cliente.dart';
import 'package:sedel_oficina_maqueta/models/orden.dart';
import 'package:sedel_oficina_maqueta/models/tecnico.dart';
import 'package:sedel_oficina_maqueta/services/orden_services.dart';
import 'package:sedel_oficina_maqueta/services/tecnico_services.dart';
import 'package:sedel_oficina_maqueta/widgets/button_delegate.dart';

import '../provider/orden_provider.dart';

class CustomizedTimetableScreen extends StatefulWidget {
  const CustomizedTimetableScreen({Key? key}) : super(key: key);
  @override
  State<CustomizedTimetableScreen> createState() =>
      _CustomizedTimetableScreenState();
}

class _CustomizedTimetableScreenState extends State<CustomizedTimetableScreen> {
  late List<TimetableItem<Orden>> items = [];
  final DateTime desde = DateTime(2023, 08, 15, 00, 00);
  final controller = TimetableController(
    start:
        DateUtils.dateOnly(DateTime.now()).subtract(const Duration(days: 30)),
    initialColumns: 7,
    cellHeight: 100.0,
  );
  Tecnico? selectedTecnico;
  late DateTimeRange selectedDate =
      DateTimeRange(start: DateTime.now(), end: DateTime.now());
  int tecnicoFiltro = 0;
  int clienteFiltro = 0;
  List<Tecnico> tecnicos = [];
  List<Orden> ordenes = [];
  final _ordenServices = OrdenServices();
  Map<String, Color> colores = {
    'PENDIENTE': Colors.yellow.shade200,
    'EN PROCESO': Colors.greenAccent.shade400,
    'REVISADA': Colors.blue.shade400,
    'FINALIZADA': Colors.red.shade200
  };
  late String token;
  late Cliente clienteSeleccionado;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      Future.delayed(const Duration(milliseconds: 100), () {
        controller.jumpTo(DateTime.now());
      });
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (tecnicos.isEmpty) {
      loadTecnicos();
    }
  }

  Future<void> loadTecnicos() async {
    final token = context.watch<OrdenProvider>().token;
    final loadedTecnicos = await TecnicoServices().getAllTecnicos(token);
    setState(() {
      tecnicos = loadedTecnicos;
      tecnicos.insert(
          0,
          Tecnico(
              tecnicoId: 0,
              codTecnico: '0',
              nombre: 'Todos',
              fechaNacimiento: null,
              documento: '',
              fechaIngreso: null,
              fechaVtoCarneSalud: null,
              deshabilitado: false,
              cargo: null));
    });
  }

  Orden obtenerOrden(int ordenId) {
    var x = ordenes.where((orden) => orden.ordenTrabajoId == ordenId).toList();
    return x[0];
  }

  myFittedBox(texto) {
    return FittedBox(
      fit: BoxFit.contain,
      child: Text(
        texto,
        style: TextStyle(fontSize: 14),
      ),
    );
  }

  List<TimetableItem<Orden>> generateItems3(List<Orden> lista) {
    final items = <TimetableItem<Orden>>[];
    lista.forEach((e) {
      items.add(TimetableItem(
        e.fechaDesde,
        e.fechaHasta,
        data: e,
      ));
    });
    return items;
  }

  void generarPlanificacion() async {
    if (clienteSeleccionado.clienteId.toString() == '0' &&
        tecnicoFiltro.toString() == '0') {
      ordenes = await _ordenServices.getOrden('', '', '', '', '', token);
    } else {
      ordenes = await _ordenServices.getOrden(
          clienteSeleccionado.clienteId.toString(),
          tecnicoFiltro.toString(),
          '',
          '',
          '',
          token);
    }
  }

  void cargarPlanificacion() {
    //se carga las ordenes desde el servicio

    List<Orden> ordenesFiltradas = [];
    ordenesFiltradas = ordenes
        .where((e) =>
            (clienteFiltro > 0 ? e.cliente.clienteId == clienteFiltro : true) &&
            (tecnicoFiltro > 0 ? e.tecnico.tecnicoId == tecnicoFiltro : true))
        .toList();
    items = generateItems3(ordenesFiltradas);
  }

  @override
  Widget build(BuildContext context) {
    token = context.read<OrdenProvider>().token;
    clienteSeleccionado = context.read<OrdenProvider>().cliente;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        automaticallyImplyLeading: false,
        actions: [
          SizedBox(
            width: 50,
          ),
          VerticalDivider(
            thickness: 3,
            color: Color.fromARGB(255, 52, 120, 62),
          ),
          DropdownButton(
            hint: Text(
              'Tecnico',
              style: TextStyle(color: Colors.white),
            ),
            value: selectedTecnico,
            dropdownColor: Color.fromARGB(255, 52, 120, 62),
            onChanged: (value) {
              setState(() {
                selectedTecnico = value;
                tecnicoFiltro = value!.tecnicoId;
              });
            },
            items: tecnicos.map((e) {
              return DropdownMenuItem(
                child: Text(
                  e.nombre,
                  style: TextStyle(color: Colors.white),
                ),
                value: e,
              );
            }).toList(),
          ),
          VerticalDivider(
            thickness: 3,
            color: Color.fromARGB(255, 52, 120, 62),
          ),
          ButtonDelegate(
            colorSeleccionado: Colors.white,
          ),
          VerticalDivider(
            thickness: 3,
            color: Color.fromARGB(255, 52, 120, 62),
          ),
          TextButton(
              onPressed: () async {
                final pickedDate = await showDateRangePicker(
                    context: context,
                    firstDate: DateTime(2023),
                    lastDate: DateTime(2025));

                if (pickedDate != null && pickedDate != selectedDate) {
                  setState(() {
                    selectedDate = pickedDate;
                    print(selectedDate);
                  });
                }
                print(pickedDate!.start);
                print(pickedDate.end);
              },
              child: Text(
                'Período',
                style: TextStyle(color: Colors.white),
              )),
          IconButton(
              onPressed: () async {
                await buscar(token);
                cargarPlanificacion();
              },
              icon: Icon(Icons.search_outlined)),
          const Spacer(),
          Container(
            child: TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text(
                        'Generar planificación',
                        style: TextStyle(fontSize: 25),
                      ),
                      content: RichText(
                        text: TextSpan(
                          style: const TextStyle(
                            fontSize: 14.0,
                            color: Colors.black,
                          ),
                          children: <TextSpan>[
                            TextSpan(
                                text:
                                    'Se va a generar la planificación automática para el período '),
                            TextSpan(
                                text: '16/09/2023 ',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                            TextSpan(text: 'hasta el '),
                            TextSpan(
                                text: '15/10/2023',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                      actions: [
                        TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text('Confirmar')),
                        TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text('Cancelar')),
                      ],
                    );
                  },
                );
                setState(() {
                  generarPlanificacion();
                  cargarPlanificacion();
                });
              },
              child: Text(
                'Generar planificación',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
          TextButton(
            child: const Text(
              "Hoy",
              style: TextStyle(color: Colors.white),
            ),
            onPressed: () => controller.jumpTo(DateTime.now()),
          ),
          IconButton(
            icon: const Icon(Icons.calendar_view_day),
            onPressed: () => controller.setColumns(1),
          ),
          IconButton(
            icon: const Icon(Icons.calendar_view_month_outlined),
            onPressed: () => controller.setColumns(30),
          ),
          IconButton(
            icon: const Icon(Icons.calendar_view_week),
            onPressed: () => controller.setColumns(7),
          ),
          IconButton(
            icon: const Icon(Icons.zoom_in),
            onPressed: () =>
                controller.setCellHeight(controller.cellHeight + 10),
          ),
          IconButton(
            icon: const Icon(Icons.zoom_out),
            onPressed: () =>
                controller.setCellHeight(controller.cellHeight - 10),
          ),
        ],
      ),
      body: Timetable<Orden>(
        controller: controller,
        items: items,
        cornerBuilder: (datetime) => Container(
          color: Colors.accents[datetime.day % Colors.accents.length],
          child: Center(child: Text("${datetime.year}")),
        ),
        headerCellBuilder: (datetime) {
          final color = Colors.primaries[datetime.day % Colors.accents.length];
          return Container(
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: color, width: 2)),
            ),
            child: Center(
              child: Text(
                DateFormat("E\nMMM d", 'es').format(datetime),
                style: TextStyle(
                  color: color,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          );
        },
        hourLabelBuilder: (time) {
          final hour = time.hour == 12 ? 12 : time.hour % 12;
          final period = time.hour < 12 ? "am" : "pm";
          final isCurrentHour = time.hour == DateTime.now().hour;
          return Text(
            "$hour$period",
            style: TextStyle(
              fontSize: 14,
              fontWeight: isCurrentHour ? FontWeight.bold : FontWeight.normal,
            ),
          );
        },
        itemBuilder: (item) => InkWell(
          onTap: () {
            final orden = obtenerOrden(item.data!.ordenTrabajoId);
            Provider.of<OrdenProvider>(context, listen: false).setOrden(orden);
            router.push('/ordenPlanificacion');
          },
          child: Container(
            decoration: BoxDecoration(
              color: colores[item.data!.estado],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 4,
                    offset: Offset(0, 2)),
              ],
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FittedBox(
                      fit: BoxFit.contain,
                      child: Text(
                        'Orden ' + item.data!.ordenTrabajoId.toString(),
                        style: TextStyle(
                            fontSize: 25, fontWeight: FontWeight.bold),
                      ),
                    ),
                    myFittedBox(item.data!.cliente.codCliente +
                        ' ' +
                        item.data!.cliente.nombre),
                    myFittedBox(item.data!.tipoOrden.descripcion),
                    myFittedBox(item.data!.estado),
                    // for (var i = 0; i < item.data!.servicio.length; i++) ...[
                    //   myFittedBox(item.data!.servicio[i].descripcion)
                    // ],
                  ],
                ),
              ),
            ),
          ),
        ),
        nowIndicatorColor: Colors.red,
        snapToDay: true,
      ),
    );
  }

  Future<void> buscar(String token) async {
    late Cliente _clienteSeleccionado = context.read<OrdenProvider>().cliente;
    print(_clienteSeleccionado.clienteId.toString());
    print(_clienteSeleccionado);

    String tecnicoId =
        selectedTecnico != null ? selectedTecnico!.tecnicoId.toString() : '';

    List<Orden> results = await _ordenServices.getOrden(
      _clienteSeleccionado.clienteId.toString(),
      tecnicoId,
      selectedDate.start.toIso8601String(),
      selectedDate.end.toIso8601String(),
      '',
      token,
    );
    setState(() {
      ordenes = results;
    });
  }
}

// List<TimetableItem<String>> generateItems() {
//   final random = Random();
//   final items = <TimetableItem<String>>[];
//   final today = DateUtils.dateOnly(DateTime.now());
//   for (var i = 0; i < 100; i++) {
//     int hourOffset = random.nextInt(56 * 24) - (7 * 24);
//     final date = today.add(Duration(hours: hourOffset));
//     items.add(TimetableItem(
//       date,
//       date.add(Duration(minutes: (random.nextInt(8) * 15) + 15)),
//       data: "item $i",
//     ));
//   }
//   return items;
// }

// List<TimetableItem<String>> generateItems2() {
//   final items = <TimetableItem<String>>[];
//   items.add(TimetableItem(
//     DateTime(2023, 9, 14, 8, 00),
//     DateTime(2023, 9, 14, 9, 00),
//     data: "Orden 1",
//   ));
//   items.add(TimetableItem(
//     DateTime(2023, 9, 14, 14, 00),
//     DateTime(2023, 9, 14, 15, 00),
//     data: "Orden 2",
//   ));
//   items.add(TimetableItem(
//     DateTime(2023, 9, 14, 14, 30),
//     DateTime(2023, 9, 14, 16, 30),
//     data: "Orden 3",
//   ));
//   return items;
// }
