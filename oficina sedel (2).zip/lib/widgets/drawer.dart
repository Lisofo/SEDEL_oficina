import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import '../provider/menu_provider.dart';
import 'icon_string.dart';

class BotonesDrawer extends StatefulWidget {
  const BotonesDrawer({super.key});

  @override
  State<BotonesDrawer> createState() => _BotonesDrawerState();
}

class _BotonesDrawerState extends State<BotonesDrawer> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: menuProvider.cargarData(),
        initialData: [],
        builder: (context, snapshot) {
          return ListView.builder(
            itemCount: menuProvider.opciones.length,
            itemBuilder: (context, index) {
              return ExpansionTile(
                title: Text(
                  menuProvider.opciones[index]['camino'],
                  style: TextStyle(color: Colors.black),
                ),
                collapsedIconColor: Colors.green.shade700,
                iconColor: Colors.green.shade700,
                initiallyExpanded: true,
                children: _filaBotones2(snapshot.data, context,
                    menuProvider.opciones[index]['opciones']),
              );
            },
          );
        });
  }
}

List<Widget> _filaBotones2(data, context, opciones) {
  final List<Widget> opcionesRet = [];
  opciones.forEach((opt) {
    final widgetTemp = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          getIcon(
            opt['icon'],
          ),
          TextButton(
              onPressed: () {
                Provider.of<OrdenProvider>(context, listen: false)
                    .setPageName(opt['texto']);
                router.push(opt['ruta']);
              },
              child: Text(
                opt['texto'],
                style: TextStyle(color: Colors.black),
              )),
        ],
      ),
    );
    opcionesRet.add(widgetTemp);
  });
  return opcionesRet;
}
