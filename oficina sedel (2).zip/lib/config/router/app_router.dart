import 'package:go_router/go_router.dart';

import '../../pages/pages.dart';

final router = GoRouter(initialLocation: '/', routes: [
  GoRoute(
    path: '/',
    builder: (context, state) => Login(),
  ),
  GoRoute(
    path: '/menu',
    builder: (context, state) => MenuPage(),
  ),
  GoRoute(
    path: '/planificador',
    builder: (context, state) => PlanificadorPage(),
  ),
  GoRoute(
    path: '/ordenesTrabajo',
    builder: (context, state) => OrdenesPlanificacion(),
  ),
  GoRoute(
    path: '/ordenPlanificacion',
    builder: (context, state) => OrdenPlan(),
  ),
  GoRoute(
    path: '/indisponibilidades',
    builder: (context, state) => IndisponibilidadesPage(),
  ),
  GoRoute(
    path: '/editIndisponibilidades',
    builder: (context, state) => EditIndisponibilidad(),
  ),
  GoRoute(
    path: '/mapa',
    builder: (context, state) => MapaPage(),
  ),
  GoRoute(
    path: '/ordenesMonitoreo',
    builder: (context, state) => MonitoreoPage(),
  ),
  GoRoute(
    path: '/clientes',
    builder: (context, state) => ClientesPage(),
  ),
  GoRoute(
    path: '/tecnicos',
    builder: (context, state) => TecnicosPage(),
  ),
  GoRoute(
    path: '/editTecnicos',
    builder: (context, state) => EditTecnicosPage(),
  ),
  GoRoute(
    path: '/tareas',
    builder: (context, state) => TareasPage(),
  ),
  GoRoute(
    path: '/editTareas',
    builder: (context, state) => EditTareasPage(),
  ),
  GoRoute(
    path: '/plagas',
    builder: (context, state) => PlagasPage(),
  ),
  GoRoute(
    path: '/editPlagas',
    builder: (context, state) => EditPlagasPage(),
  ),
  GoRoute(
    path: '/plagas_objetivo',
    builder: (context, state) => PlagasObjetivoPage(),
  ),
  GoRoute(
    path: '/editPlagasObjetivo',
    builder: (context, state) => EditPlagasObjetivoPage(),
  ),
  GoRoute(
    path: '/usuarios',
    builder: (context, state) => UsuariosPage(),
  ),
  GoRoute(
    path: '/editUsuarios',
    builder: (context, state) => EditUsuariosPage(),
  ),
  GoRoute(
    path: '/editPwdPin',
    builder: (context, state) => EditPwdPin(),
  ),
  GoRoute(
    path: '/establecerClientes',
    builder: (context, state) => EstablecerClientes(),
  ),
  GoRoute(
    path: '/servicios',
    builder: (context, state) => ServiciosPage(),
  ),
  GoRoute(
    path: '/editServicios',
    builder: (context, state) => EditServiciosPage(),
  ),
  GoRoute(
    path: '/materiales',
    builder: (context, state) => MaterialesPage(),
  ),
  GoRoute(
    path: '/editMateriales',
    builder: (context, state) => EditMaterialesPage(),
  ),
  GoRoute(
    path: '/revisionOrden',
    builder: (context, state) => RevisionOrdenPage(),
  ),
]);
