class Config {
  static const String APIURL = String.fromEnvironment("APIURL");
  static const String APIFSURL = String.fromEnvironment("APIFSURL");
}
