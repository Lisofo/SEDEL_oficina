import 'package:flutter/material.dart';
import 'package:sedel_oficina_maqueta/pages/Monitoreo%20Diario/monitoreo.dart';
import 'package:sedel_oficina_maqueta/pages/PyR/indisponibilidades/edit_indisponibilidad.dart';
import 'package:sedel_oficina_maqueta/pages/gestion/clientes/clientes.dart';
import 'package:sedel_oficina_maqueta/pages/menu/menu.dart';

import '../pages/Monitoreo Diario/mapa.dart';
import '../pages/PyR/indisponibilidades/indisponibilidades.dart';
import '../pages/PyR/ordenesPlanificacion/orden/ordenTrabajo.dart';
import '../pages/PyR/ordenesPlanificacion/ordenPlanificacion.dart';
import '../pages/PyR/planificador/planificador.dart';
import '../pages/login/login.dart';

Map<String, WidgetBuilder> getAppRoute() {
  return <String, WidgetBuilder>{
    '/': (context) => Login(),
    'menu': (context) => MenuPage(),
    'planificador': (context) => PlanificadorPage(),
    'ordenesTrabajo': (context) => OrdenesPlanificacion(),
    'ordenPlanificacion': (context) => OrdenPlan(),
    // 'ordenRevision':(context) => OrdenRevision(),
    'indisponibilidades': (context) => IndisponibilidadesPage(),
    'editIndisponibilidades':(context) => EditIndisponibilidad(),
    'mapa': (context) => MapaPage(),
    'ordenesMontitoreo': (context) => MonitoreoPage(),
    'clientes':(context) => ClientesPage(),
  };
}
