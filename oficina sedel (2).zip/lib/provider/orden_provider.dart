// ignore_for_file: unused_field

import 'package:flutter/material.dart';
import 'package:sedel_oficina_maqueta/models/material.dart';
import 'package:sedel_oficina_maqueta/models/plaga.dart';
import 'package:sedel_oficina_maqueta/models/plaga_objetivo.dart';
import 'package:sedel_oficina_maqueta/models/servicio.dart';
import 'package:sedel_oficina_maqueta/models/tarea.dart';
import 'package:sedel_oficina_maqueta/models/tecnico.dart';
import 'package:sedel_oficina_maqueta/models/usuario.dart';
import '../models/cliente.dart';
import '../models/orden.dart';

class OrdenProvider with ChangeNotifier {
  Orden _orden = Orden.empty();
  Orden get orden => _orden;

  void setOrden(Orden orden) {
    _orden = orden;
    notifyListeners();
  }

  String _menu = '';
  String get menu => _menu;

  void setPage(String codPages) {
    _menu = codPages;
    notifyListeners();
  }

  String _menuName = '';
  String get menuName => _menuName;

  void setPageName(String codPagesName) {
    _menuName = codPagesName;
    notifyListeners();
  }

  String _token = '';
  String get token => _token;

  void setToken(String tok) {
    _token = tok;
    notifyListeners();
  }

  Cliente _cliente = Cliente.empty();
  Cliente get cliente => _cliente;

  void setCliente(Cliente cli) {
    _cliente = cli;
    notifyListeners();
  }

  Cliente? _selectedCliente;
  void clearSelectedCliente() {
    _cliente = Cliente.empty();
    notifyListeners();
  }

  Tecnico _tecnico = Tecnico.empty();
  Tecnico get tecnico => _tecnico;

  void setTecnico(Tecnico tec) {
    _tecnico = tec;
    notifyListeners();
  }

  Tecnico? _selectedTecnico;
  void clearSelectedTecnico() {
    _tecnico = Tecnico.empty();
    notifyListeners();
  }

  Tarea _tarea = Tarea.empty();
  Tarea get tarea => _tarea;

  void setTarea(Tarea task) {
    _tarea = task;
    notifyListeners();
  }

  Tarea? _selectedTarea;
  void clearSelectedTarea() {
    _tarea = Tarea.empty();
    notifyListeners();
  }

  Servicio _servicio = Servicio.empty();
  Servicio get servicio => _servicio;

  void setServicio(Servicio service) {
    _servicio = service;
    notifyListeners();
  }

  Servicio? _selectedServicio;
  void clearSelectedServicio() {
    _servicio = Servicio.empty();
    notifyListeners();
  }

  Plaga _plaga = Plaga.empty();
  Plaga get plaga => _plaga;

  void setPlaga(Plaga pest) {
    _plaga = pest;
    notifyListeners();
  }

  Plaga? _selectedPlaga;
  void clearSelectedPlaga() {
    _plaga = Plaga.empty();
    notifyListeners();
  }

  PlagaObjetivo _plagaObjetivo = PlagaObjetivo.empty();
  PlagaObjetivo get plagaObjetivo => _plagaObjetivo;

  void setPlagaObjetivo(PlagaObjetivo pestObjetivo) {
    _plagaObjetivo = pestObjetivo;
    notifyListeners();
  }

  Plaga? _selectedPlagaObjetivo;
  void clearSelectedPlagaObjetivo() {
    _plaga = Plaga.empty();
    notifyListeners();
  }

  Usuario _usuario = Usuario.empty();
  Usuario get usuario => _usuario;

  void setUsuario(Usuario user) {
    _usuario = user;
    notifyListeners();
  }

  Usuario? _selectedUsuario;
  void clearSelectedUsuario() {
    _usuario = Usuario.empty();
    notifyListeners();
  }

  Materiales _materiales = Materiales.empty();
  Materiales get materiales => _materiales;

  void setMateriales(Materiales materials) {
    _materiales = materials;
    notifyListeners();
  }

  Materiales? _selectedmateriales;
  void clearSelectedMaterial() {
    _materiales = Materiales.empty();
    notifyListeners();
  }
}
