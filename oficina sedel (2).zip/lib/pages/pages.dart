export 'package:sedel_oficina_maqueta/pages/login/login.dart';
export 'package:sedel_oficina_maqueta/pages/menu/menu.dart';

export 'package:sedel_oficina_maqueta/pages/PyR/planificador/planificador.dart';
export 'package:sedel_oficina_maqueta/pages/PyR/indisponibilidades/indisponibilidades.dart';
export 'package:sedel_oficina_maqueta/pages/PyR/indisponibilidades/edit_indisponibilidad.dart';
export 'package:sedel_oficina_maqueta/pages/PyR/ordenesPlanificacion/orden/ordenTrabajo.dart';
export 'package:sedel_oficina_maqueta/pages/PyR/ordenesPlanificacion/ordenPlanificacion.dart';

export 'package:sedel_oficina_maqueta/pages/gestion/plagas/plagas.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/plagas/editPlagas.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/tareas/tareas.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/tareas/editTareas.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/tecnicos/tecnicos.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/tecnicos/editTecnicos.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/clientes/clientes.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/plagasObjetivo/plagas_objetivo.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/plagasObjetivo/edit_plagas_objetivo.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/servicios/servicios.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/servicios/editServicios.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/materiales/materiales.dart';
export 'package:sedel_oficina_maqueta/pages/gestion/materiales/editMateriales.dart';

export 'package:sedel_oficina_maqueta/pages/sistema/usuarios/establecer_clientes.dart';
export 'package:sedel_oficina_maqueta/pages/sistema/usuarios/password_pin.dart';
export 'package:sedel_oficina_maqueta/pages/sistema/usuarios/editUsuarios.dart';
export 'package:sedel_oficina_maqueta/pages/sistema/usuarios/usuarios.dart';

export 'package:sedel_oficina_maqueta/pages/Monitoreo%20Diario/monitoreo.dart';
export 'package:sedel_oficina_maqueta/pages/Monitoreo%20Diario/mapa.dart';
export 'package:sedel_oficina_maqueta/pages/Monitoreo%20Diario/revisionOrden.dart';
