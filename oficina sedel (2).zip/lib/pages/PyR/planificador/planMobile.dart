import 'package:flutter/material.dart';

class PlanMobile extends StatefulWidget {
  const PlanMobile({super.key});

  @override
  State<PlanMobile> createState() => _PlanMobileState();
}

class _PlanMobileState extends State<PlanMobile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
