import 'package:flutter/material.dart';

class IndisponibilidadesMobile extends StatefulWidget {
  const IndisponibilidadesMobile({super.key});

  @override
  State<IndisponibilidadesMobile> createState() => _IndisponibilidadesMobileState();
}

class _IndisponibilidadesMobileState extends State<IndisponibilidadesMobile> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}