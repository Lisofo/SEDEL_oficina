import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/models/indisponibilidades.dart';
import 'package:sedel_oficina_maqueta/services/indis_services.dart';
import 'package:sedel_oficina_maqueta/services/tecnico_services.dart';
import 'package:sedel_oficina_maqueta/widgets/appbar.dart';
import 'package:sedel_oficina_maqueta/widgets/button_delegate.dart';
import 'package:sedel_oficina_maqueta/widgets/drawer.dart';
import 'package:intl/intl.dart';

import '../../../models/cliente.dart';
import '../../../models/tecnico.dart';
import '../../../provider/orden_provider.dart';

class IndisponibilidadesDesktop extends StatefulWidget {
  const IndisponibilidadesDesktop({super.key});

  @override
  State<IndisponibilidadesDesktop> createState() =>
      _IndisponibilidadesDesktopState();
}

class _IndisponibilidadesDesktopState extends State<IndisponibilidadesDesktop> {
  List<Tecnico> tecnicos = [];

  List<String> tipoIndisponibilidad = [
    'Todas',
    'General o global',
    'Indisponibilidad del cliente',
    'Indisponibilidad del tecnico'
  ];
  List<Indisponibilidad> indisponibilidades = [];
  Tecnico? selectedTecnico;
  Cliente? selectedCliente;
  String? selectedTipo = 'Todas';
  int tecnicoFiltro = 0;
  int clienteFiltro = 0;
  final _indisponibilidadServices = IndisponibilidadServices();

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (tecnicos.isEmpty) {
      loadTecnicos();
    }
  }

  Future<void> loadTecnicos() async {
    final token = context.watch<OrdenProvider>().token;
    final loadedTecnicos = await TecnicoServices().getAllTecnicos(token);
    setState(() {
      tecnicos = loadedTecnicos;
    });
  }

  @override
  Widget build(BuildContext context) {
    final token = context.watch<OrdenProvider>().token;

    return Scaffold(
      appBar: AppBarDesign(titulo: 'Indisponibilidades',),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Row(
        children: [
          Flexible(
            flex: 2,
            child: Container(
              child: Card(
                elevation: 40,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Seleccione periodo: '),
                          TextButton(
                              onPressed: () {
                                showDateRangePicker(
                                    context: context,
                                    firstDate: DateTime.now(),
                                    lastDate: DateTime(2099));
                              },
                              child: Text(
                                'Período',
                                style: TextStyle(color: Colors.black),
                              )),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Tecnico: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text('Tecnico'),
                            value: selectedTecnico,
                            onChanged: (value) {
                              setState(() {
                                selectedTecnico = value;
                                tecnicoFiltro = value!.tecnicoId;
                              });
                            },
                            items: tecnicos.map((e) {
                              return DropdownMenuItem(
                                child: Text(e.nombre),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Cliente: '),
                          SizedBox(
                            width: 10,
                          ),
                          ButtonDelegate(
                            colorSeleccionado: Colors.black,
                          )
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Tipo de indisponibilidad: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text(
                              'Tipo de indisponibilidad',
                            ),
                            value: selectedTipo,
                            onChanged: (value) {
                              setState(() {
                                selectedTipo = value;
                              });
                            },
                            items: tipoIndisponibilidad.map((e) {
                              return DropdownMenuItem(
                                child: Text(e),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Center(
                        child: ElevatedButton(
                            style: ButtonStyle(
                                backgroundColor:
                                    MaterialStatePropertyAll(Colors.white),
                                elevation: MaterialStatePropertyAll(10),
                                shape: MaterialStatePropertyAll(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.horizontal(
                                            left: Radius.circular(50),
                                            right: Radius.circular(50))))),
                            onPressed: () async {
                              List<Indisponibilidad> results =
                                  await _indisponibilidadServices
                                      .getIndisponibilidad(context, '', '', '',
                                          '', '', '', token);
                              setState(() {
                                indisponibilidades = results;
                              });
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.5),
                              child: Text(
                                'Buscar',
                                style: TextStyle(
                                  color: Color.fromARGB(255, 52, 120, 62),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )),
                      ),
                      Spacer(),
                      Center(
                        child: ElevatedButton(
                            style: ButtonStyle(
                                backgroundColor:
                                    MaterialStatePropertyAll(Colors.white),
                                elevation: MaterialStatePropertyAll(10),
                                shape: MaterialStatePropertyAll(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.horizontal(
                                            left: Radius.circular(50),
                                            right: Radius.circular(50))))),
                            onPressed: () {},
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.5),
                              child: Text(
                                'Crear Indisponibilidad',
                                style: TextStyle(
                                  color: Color.fromARGB(255, 52, 120, 62),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            flex: 4,
            child: Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: indisponibilidades.length,
                    itemBuilder: (context, i) {
                      return InkWell(
                        onTap: () {
                          // Provider.of<OrdenProvider>(context, listen: false)
                          //     .setOrden(indisponibilidades[i]);
                          router.push('/editIndisponibilidades');
                        },
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Flexible(
                                  flex: 2,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: CircleAvatar(
                                          backgroundColor:
                                              Color.fromARGB(255, 52, 120, 62),
                                          foregroundColor: Colors.white,
                                          child: Text(indisponibilidades[i]
                                              .indisponibilidadId
                                              .toString()),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 30,
                                      ),
                                      Flexible(
                                        flex: 1,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(indisponibilidades[i]
                                                    .cliente!
                                                    .codCliente +
                                                ' ' +
                                                indisponibilidades[i]
                                                    .cliente!
                                                    .nombre),
                                            Row(
                                              children: [
                                                Text(
                                                    'Tecnico: ${indisponibilidades[i].tecnico!.nombre}'),
                                              ],
                                            ),
                                            Text(
                                                'Tipo de indisponibilidad: ${indisponibilidades[i].tipoIndisponibilidad.descripcion}')
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // Spacer(),
                                // Flexible(
                                //   flex: 2,
                                //   child: Wrap(children: [
                                //     for (var j = 0;
                                //         j <
                                //             indisponibilidades[i]
                                //                 .servicios
                                //                 .length;
                                //         j++) ...[
                                //       Text(ordenesFiltradas[i]
                                //               .servicios[j]
                                //               .descripcion +
                                //           ' | '),
                                //     ],
                                //   ]),
                                // ),
                                Spacer(),
                                Flexible(
                                  flex: 1,
                                  child: Column(
                                    children: [
                                      Text(DateFormat("E d, MMM, hh:mm", 'es')
                                          .format(indisponibilidades[i].desde)),
                                      Text(DateFormat("E d, MMM, hh:mm", 'es')
                                          .format(indisponibilidades[i].hasta)),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
