// ignore_for_file: unused_field

import 'package:flutter/material.dart';
import 'package:sedel_oficina_maqueta/models/tecnico.dart';
import 'package:sedel_oficina_maqueta/widgets/appbar.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_dropdown.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';
import 'package:sedel_oficina_maqueta/widgets/drawer.dart';
import 'package:intl/intl.dart';

class EditIndisponibilidad extends StatefulWidget {
  const EditIndisponibilidad({super.key});

  @override
  State<EditIndisponibilidad> createState() => _EditIndisponibilidadState();
}

class _EditIndisponibilidadState extends State<EditIndisponibilidad> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBarDesign(titulo: '',),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: IndisponibilidadView(),
    );
  }
}

class IndisponibilidadView extends StatelessWidget {
  const IndisponibilidadView();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Flexible(
                  flex: 1,
                  child: Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: IndisponibilidadForm(),
                      )),
                ),
                SizedBox(
                  width: 40,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [/*Aca estaba el campo de observaciones*/],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class IndisponibilidadForm extends StatefulWidget {
  const IndisponibilidadForm();

  @override
  State<IndisponibilidadForm> createState() => _IndisponibilidadFormState();
}

class _IndisponibilidadFormState extends State<IndisponibilidadForm> {
  final GlobalKey<FormState> _globalKey = GlobalKey<FormState>();
  List<String> tipoIndisponibilidad = [
    'General o global',
    'Indisponibilidad del cliente',
    'Indisponibilidad del tecnico'
  ];
  List<Tecnico> tecnicos = [];
  late String _setDate;
  late String dateTime;
  late String selectedTipo = '';
  late Tecnico? selectedTecnico;
  DateTime selectedDate = DateTime.now();
  TextEditingController _dateController = TextEditingController();
  TextEditingController _dateHastaController = TextEditingController();
  Future<Null> _selectDateDesde(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(2015),
        lastDate: DateTime(2099));
    if (picked != null)
      setState(() {
        selectedDate = picked;
        _dateController.text = DateFormat.yMd().format(selectedDate);
      });
  }

  Future<Null> _selectDateHasta(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(2015),
        lastDate: DateTime(2099));
    if (picked != null)
      setState(() {
        selectedDate = picked;
        _dateHastaController.text = DateFormat.yMd().format(selectedDate);
      });
  }

  @override
  void initState() {
    _dateController.text = DateFormat.yMd().format(DateTime.now());
    _dateHastaController.text = DateFormat.yMd().format(DateTime.now());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _globalKey,
      child: Column(
        children: [
          Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    width: 300,
                    child: CustomDropdownFormMenu(
                      hint: 'Seleccione una indisponibilidad',
                      items: tipoIndisponibilidad
                          .map((item) => DropdownMenuItem(
                                value: item,
                                child: Text(
                                  item,
                                  style: const TextStyle(
                                    fontSize: 14,
                                  ),
                                ),
                              ))
                          .toList(),
                      validator: (value) {
                        if (value?.isEmpty ?? true)
                          return 'Seleccione un tipo de indisponibilidad';
                        return null;
                      },
                      onChanged: (value) {
                        selectedTipo = value!;
                      },
                      onSaved: (value) {
                        selectedTipo = value!;
                      },
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      IconButton.filledTonal(
                          onPressed: () => _selectDateDesde(context),
                          icon: Icon(Icons.calendar_month)),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          label: 'Fecha desde',
                          textAling: TextAlign.center,
                          controller: _dateController,
                          onSaved: (value) {
                            _setDate = value!;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      IconButton.filledTonal(
                          onPressed: () => _selectDateHasta(context),
                          icon: Icon(Icons.calendar_month)),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          label: 'Fecha hasta',
                          textAling: TextAlign.center,
                          controller: _dateHastaController,
                          onSaved: (value) {
                            _setDate = value!;
                          },
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Seleccione una fecha hasta';
                            } else {
                              // Parsea las fechas desde los controladores a objetos DateTime
                              final fechaDesde =
                                  DateFormat.yMd().parse(_dateController.text);
                              final fechaHasta = DateFormat.yMd().parse(value);

                              if (fechaHasta.isBefore(fechaDesde)) {
                                return 'La fecha seleccionada es incorrecta seleccione \nuna fecha mayor o igual a la inicial';
                              }
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Icon(Icons.groups),
                      SizedBox(
                        width: 10,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          label: 'Cliente',
                          validator: (value) {
                            if (selectedTipo == '') return null;
                            if (selectedTipo == 'General o global') {
                              if (value != '') {
                                return 'Campo invalido';
                              } else
                                return null;
                            } else if (selectedTipo ==
                                'Indisponibilidad del cliente') {
                              if (value == '') {
                                return 'Seleccione un cliente';
                              } else
                                return null;
                            } else if (selectedTipo ==
                                'Indisponibilidad del tecnico') {
                              if (value != '') {
                                return "Campo invalido";
                              } else
                                return null;
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    width: 300,
                    child: CustomDropdownFormMenu(
                      hint: 'Seleccione un tecnico',
                      items: tecnicos
                          .map((e) => DropdownMenuItem(
                                value: e,
                                child: Text(
                                  e.nombre,
                                  style: const TextStyle(
                                    fontSize: 14,
                                  ),
                                ),
                              ))
                          .toList(),
                      onChanged: (value) {
                        selectedTecnico = value!;
                      },
                      validator: (value) {
                        if (selectedTipo == '') return null;
                        if (selectedTipo == 'General o global') {
                          if (value != null && value.tecnicoId != 0) {
                            return 'Campo invalido';
                          } else
                            return null;
                        } else if (selectedTipo ==
                            'Indisponibilidad del cliente') {
                          if (value != null && value.tecnicoId != 0) {
                            return 'Campo invalido';
                          } else
                            return null;
                        } else if (selectedTipo ==
                            'Indisponibilidad del tecnico') {
                          if (value == null || value.tecnicoId == 0) {
                            return "Seleccione un tecnico";
                          } else
                            return null;
                        }
                        return null;
                      },
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                ],
              ),
              SizedBox(
                width: 150,
              ),
              Column(
                children: [
                  Text(
                    'Observaciones',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                      width: 800,
                      height: 500,
                      child: CustomTextFormField(
                        label: 'Observaciones',
                        maxLines: 20,
                        validator: (value) {
                          if (value == null || value.isEmpty)
                            return 'Campo requerido';
                          if (value.trim().isEmpty) return 'Campo requerido';
                          return null;
                        },
                      )),
                ],
              ),
              SizedBox(
                width: 150,
              ),
            ],
          ),
          Spacer(),
          BottomAppBar(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStatePropertyAll(Colors.white),
                          elevation: MaterialStatePropertyAll(10),
                          shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.horizontal(
                                      left: Radius.circular(50),
                                      right: Radius.circular(50))))),
                      onPressed: () {
                        _globalKey.currentState?.validate();
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.5),
                        child: Text(
                          'Guardar',
                          style: TextStyle(
                              color: Color.fromARGB(255, 52, 120, 62),
                              fontWeight: FontWeight.bold,
                              fontSize: 20),
                        ),
                      )),
                  SizedBox(
                    width: 30,
                  ),
                  ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStatePropertyAll(Colors.white),
                          elevation: MaterialStatePropertyAll(10),
                          shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.horizontal(
                                      left: Radius.circular(50),
                                      right: Radius.circular(50))))),
                      onPressed: () {},
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.5),
                        child: Text(
                          'Modificar',
                          style: TextStyle(
                              color: Color.fromARGB(255, 52, 120, 62),
                              fontWeight: FontWeight.bold,
                              fontSize: 20),
                        ),
                      )),
                  SizedBox(
                    width: 30,
                  ),
                  ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStatePropertyAll(Colors.white),
                          elevation: MaterialStatePropertyAll(10),
                          shape: MaterialStatePropertyAll(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.horizontal(
                                      left: Radius.circular(50),
                                      right: Radius.circular(50))))),
                      onPressed: () {},
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.5),
                        child: Text(
                          'Eliminar',
                          style: TextStyle(
                              color: Color.fromARGB(255, 52, 120, 62),
                              fontWeight: FontWeight.bold,
                              fontSize: 20),
                        ),
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
