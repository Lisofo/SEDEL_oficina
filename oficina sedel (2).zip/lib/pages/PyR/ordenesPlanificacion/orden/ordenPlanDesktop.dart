import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/services/orden_services.dart';
import 'package:sedel_oficina_maqueta/services/tecnico_services.dart';
import 'package:sedel_oficina_maqueta/widgets/button_delegate.dart';

import '../../../../models/cliente.dart';
import '../../../../models/orden.dart';
import '../../../../models/tecnico.dart';
import '../../../../provider/orden_provider.dart';
import '../../../../widgets/appbar.dart';
import '../../../../widgets/drawer.dart';

class OrdenPlanDesktop extends StatefulWidget {
  const OrdenPlanDesktop({super.key});

  @override
  State<OrdenPlanDesktop> createState() => _OrdenPlanDesktopState();
}

class _OrdenPlanDesktopState extends State<OrdenPlanDesktop> {
  List<Tecnico> tecnicos = [];
  List<Orden> ordenes = [];
  List<String> estados = [
    'Todos',
    'Pendiente',
    'En Proceso',
    'Finalizado',
    'Revisada',
  ];
  List<String> servicios = [
    'Monitoreo de insectos voladores con trampas de luz UV',
    'Monitoreo sistema de desinfección automática de vehículos',
    'Monitoreo y control de abejas',
    'Monitoreo y control de arañas',
    'Monitoreo y control de aves',
    'Monitoreo y control de avispas/lechiguanas',
    'Monitoreo y control de coleopteros',
    'Monitoreo y control de comadrejas / gatos',
    'Monitoreo y control de cucarachas',
    'Monitoreo y control de garrapatas',
    'Monitoreo y control de hormigas',
    'Monitoreo y control de insectos',
    'Monitoreo y control de langostas'
  ];
  List<String> materiales = [
    'Alfaplus NF',
    'Sipertrin',
    'Ultra Pum',
    'Rigon Cebo Blando',
    'Starycide SC',
    'Fendona 6 SC'
  ];
  List<String> tipoOrden = [
    'Todos',
    'Normal',
    'Diagnostico',
    'Control de calidad'
  ];
  List<Orden> ordenesFiltradas = [];
  String? selectedServicio;
  String? selectedMaterial;
  late DateTimeRange selectedDate =
      DateTimeRange(start: DateTime.now(), end: DateTime.now());
  Tecnico? selectedTecnico;
  String? selectedEstado = 'Todos';
  String? selectedTipo = 'Todos';
  int tecnicoFiltro = 0;
  int clienteFiltro = 0;
  final _ordenServices = OrdenServices();
  // late Cliente _clienteSeleccionado = context.read<OrdenProvider>().cliente;

  void filtro() {
    ordenesFiltradas = ordenes
        .where((e) =>
            (clienteFiltro > 0 ? e.cliente.clienteId == clienteFiltro : true) &&
            (tecnicoFiltro > 0 ? e.tecnico.tecnicoId == tecnicoFiltro : true) &&
            (selectedEstado != 'Todos' ? e.estado == selectedEstado : true) &&
            (selectedTipo != 'Todos' ? e.tipoOrden == selectedTipo : true))
        .toList();
    print(ordenes.length);
    print("ordenesFiltradas después de filtro: ${ordenesFiltradas.length}");
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (tecnicos.isEmpty) {
      loadTecnicos();
    }
  }

  Future<void> loadTecnicos() async {
    final token = context.watch<OrdenProvider>().token;
    final loadedTecnicos = await TecnicoServices().getAllTecnicos(token);
    setState(() {
      tecnicos = loadedTecnicos;
    });
  }

  @override
  Widget build(BuildContext context) {
    final token = context.read<OrdenProvider>().token;

    return Scaffold(
      appBar: AppBarDesign(titulo: '',),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Row(
        children: [
          Flexible(
            flex: 2,
            child: Container(
              child: Card(
                elevation: 40,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Seleccione periodo: '),
                          TextButton(
                              onPressed: () async {
                                final pickedDate = await showDateRangePicker(
                                    context: context,
                                    firstDate: DateTime(2023),
                                    lastDate: DateTime(2025));

                                if (pickedDate != null &&
                                    pickedDate != selectedDate) {
                                  setState(() {
                                    selectedDate = pickedDate;
                                    print(selectedDate);
                                  });
                                }
                                print(pickedDate!.start);
                                print(pickedDate.end);
                              },
                              child: Text(
                                'Período',
                                style: TextStyle(color: Colors.black),
                              )),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Tecnico: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text('Tecnico'),
                            value: selectedTecnico,
                            onChanged: (value) {
                              setState(() {
                                selectedTecnico = value;
                                tecnicoFiltro = value!.tecnicoId;
                              });
                            },
                            items: tecnicos.map((e) {
                              return DropdownMenuItem(
                                child: Text(e.nombre),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Estado: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text('Estado'),
                            value: selectedEstado,
                            onChanged: (value) {
                              setState(() {
                                selectedEstado = value;
                              });
                            },
                            items: estados.map((e) {
                              return DropdownMenuItem(
                                child: Text(e),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Cliente: '),
                          SizedBox(
                            width: 10,
                          ),
                          ButtonDelegate(
                            colorSeleccionado: Colors.black,
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Servicios: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text('Servicios'),
                            itemHeight: null,
                            value: selectedServicio,
                            onChanged: (value) {
                              setState(() {
                                selectedServicio = value;
                              });
                            },
                            items: servicios.map((e) {
                              return DropdownMenuItem(
                                child: SizedBox(
                                  width: 300,
                                  child: Text(
                                    e,
                                    overflow: TextOverflow.fade,
                                  ),
                                ),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Materiales: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text('Materiales'),
                            value: selectedMaterial,
                            onChanged: (value) {
                              setState(() {
                                selectedMaterial = value;
                              });
                            },
                            items: materiales.map((e) {
                              return DropdownMenuItem(
                                child: SizedBox(width: 300, child: Text(e)),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Tipo de orden: '),
                          SizedBox(
                            width: 10,
                          ),
                          DropdownButton(
                            hint: Text(
                              'Tipo de orden',
                            ),
                            value: selectedTipo,
                            onChanged: (value) {
                              setState(() {
                                selectedTipo = value;
                              });
                            },
                            items: tipoOrden.map((e) {
                              return DropdownMenuItem(
                                child: Text(e),
                                value: e,
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Text('Nro. Orden:'),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                              width: 200,
                              decoration: BoxDecoration(border: Border.all()),
                              child: TextField(
                                decoration:
                                    InputDecoration(border: InputBorder.none),
                              ))
                        ],
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Center(
                        child: ElevatedButton(
                            style: ButtonStyle(
                                backgroundColor:
                                    MaterialStatePropertyAll(Colors.white),
                                elevation: MaterialStatePropertyAll(10),
                                shape: MaterialStatePropertyAll(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.horizontal(
                                            left: Radius.circular(50),
                                            right: Radius.circular(50))))),
                            onPressed: () async {
                              await buscar(token);
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.5),
                              child: Text(
                                'Buscar',
                                style: TextStyle(
                                  color: Color.fromARGB(255, 52, 120, 62),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )),
                      ),
                      Spacer(),
                      Center(
                        child: ElevatedButton(
                            style: ButtonStyle(
                                backgroundColor:
                                    MaterialStatePropertyAll(Colors.white),
                                elevation: MaterialStatePropertyAll(10),
                                shape: MaterialStatePropertyAll(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.horizontal(
                                            left: Radius.circular(50),
                                            right: Radius.circular(50))))),
                            onPressed: () {},
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 8.5),
                              child: Text(
                                'Crear Orden',
                                style: TextStyle(
                                  color: Color.fromARGB(255, 52, 120, 62),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            flex: 4,
            child: Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: ordenesFiltradas.length,
                    itemBuilder: (context, i) {
                      return InkWell(
                        onTap: () {
                          Provider.of<OrdenProvider>(context, listen: false)
                              .setOrden(ordenesFiltradas[i]);
                          router.push('/ordenPlanificacion');
                        },
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Flexible(
                                  flex: 3,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: CircleAvatar(
                                          backgroundColor:
                                              Color.fromARGB(255, 52, 120, 62),
                                          foregroundColor: Colors.white,
                                          child: Text(ordenesFiltradas[i]
                                              .ordenTrabajoId
                                              .toString()),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 30,
                                      ),
                                      Flexible(
                                        flex: 2,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(ordenesFiltradas[i]
                                                    .cliente
                                                    .codCliente +
                                                ' ' +
                                                ordenesFiltradas[i]
                                                    .cliente
                                                    .nombre),
                                            Row(
                                              children: [
                                                Text(
                                                    'Tecnico: ${ordenesFiltradas[i].tecnico.nombre}'),
                                              ],
                                            ),
                                            Text(
                                                'Tipo de orden: ${ordenesFiltradas[i].tipoOrden.descripcion}'),
                                            Text(
                                                'Estado: ${ordenesFiltradas[i].estado}'),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(),
                                Flexible(
                                  flex: 2,
                                  child: Wrap(children: [
                                    for (var j = 0;
                                        j < ordenesFiltradas[i].servicio.length;
                                        j++) ...[
                                      Text(ordenesFiltradas[i]
                                              .servicio[j]
                                              .descripcion +
                                          ' | '),
                                    ],
                                  ]),
                                ),
                                Spacer(),
                                Flexible(
                                  flex: 1,
                                  child: Column(
                                    children: [
                                      Text(DateFormat("E d, MMM", 'es').format(
                                          ordenesFiltradas[i].fechaDesde)),
                                      Text(DateFormat("E d, MMM", 'es').format(
                                          ordenesFiltradas[i].fechaHasta)),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> buscar(String token) async {
    late Cliente _clienteSeleccionado = context.read<OrdenProvider>().cliente;
    print(_clienteSeleccionado.clienteId.toString());
    print(_clienteSeleccionado);

    String tecnicoId =
        selectedTecnico != null ? selectedTecnico!.tecnicoId.toString() : '';

    List<Orden> results = await _ordenServices.getOrden(
      _clienteSeleccionado.clienteId.toString(),
      tecnicoId,
      selectedDate.start.toIso8601String(),
      selectedDate.end.toIso8601String(),
      '',
      token,
    );
    setState(() {
      ordenesFiltradas = results;
    });
  }
}
