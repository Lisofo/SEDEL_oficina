import 'package:flutter/material.dart';

class OrdenPlanMobile extends StatefulWidget {
  const OrdenPlanMobile({super.key});

  @override
  State<OrdenPlanMobile> createState() => _OrdenPlanMobileState();
}

class _OrdenPlanMobileState extends State<OrdenPlanMobile> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}