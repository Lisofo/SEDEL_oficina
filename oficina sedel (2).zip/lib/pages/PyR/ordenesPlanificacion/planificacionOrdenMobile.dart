import 'package:flutter/material.dart';

class OrdenPlanificacionMobile extends StatefulWidget {
  const OrdenPlanificacionMobile({super.key});

  @override
  State<OrdenPlanificacionMobile> createState() => _OrdenPlanificacionMobileState();
}

class _OrdenPlanificacionMobileState extends State<OrdenPlanificacionMobile> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}