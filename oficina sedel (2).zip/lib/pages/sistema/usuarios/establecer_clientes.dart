import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/models/cliente.dart';
import 'package:sedel_oficina_maqueta/models/cliente_usuario.dart';
import 'package:sedel_oficina_maqueta/models/usuario.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/search/client_delegate.dart';
import 'package:sedel_oficina_maqueta/services/user_services.dart';

import '../../../widgets/appbar.dart';
import '../../../widgets/drawer.dart';

class EstablecerClientes extends StatefulWidget {
  const EstablecerClientes({super.key});

  @override
  State<EstablecerClientes> createState() => _EstablecerClientesState();
}

class _EstablecerClientesState extends State<EstablecerClientes> {
  final _userServices = UserServices();
  List<ClienteUsuario> clientes = [];
  late Usuario userSeleccionado;
  late String token;
  List<Cliente> historial = [];
  late Cliente selectedCliente = Cliente.empty();
  @override
  void initState() {
    super.initState();
    userSeleccionado = context.read<OrdenProvider>().usuario;
    token = context.read<OrdenProvider>().token;
    getClientes(userSeleccionado, token);
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarDesign(
        titulo: 'Usuarios',
      ),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
              child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(children: [
              Container(
                  height: 400,
                  child: ListView.separated(
                    itemCount: clientes.length,
                    itemBuilder: (context, index) {
                      final _clientes = clientes;
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 300),
                        child: ListTile(
                          title: Text(
                            _clientes[index].cliente,
                            textAlign: TextAlign.center,
                          ),
                          subtitle: Text(
                            _clientes[index].codCliente,
                            textAlign: TextAlign.center,
                          ),
                          trailing: IconButton(
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      title: Text('Confirmar accion'),
                                      content: Container(
                                        child: Text(
                                            'Desea borrar ${_clientes[index].cliente}?'),
                                      ),
                                      actions: [
                                        TextButton(
                                            onPressed: () async {
                                              await _userServices
                                                  .deleteClientUsers(
                                                      context,
                                                      userSeleccionado.usuarioId
                                                          .toString(),
                                                      _clientes[index]
                                                          .clienteId
                                                          .toString(),
                                                      token);
                                              await getClientes(
                                                  userSeleccionado, token);
                                            },
                                            child: Text('Borrar')),
                                        TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: Text('Cancelar'))
                                      ],
                                    );
                                  },
                                );
                              },
                              icon: Icon(Icons.delete)),
                        ),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 300),
                        child: Divider(
                          thickness: 3,
                          color: Colors.green,
                        ),
                      );
                    },
                  )),
            ]),
          ))),
      bottomNavigationBar: BottomAppBar(
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(Colors.white),
                      elevation: MaterialStatePropertyAll(10),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                          borderRadius: BorderRadius.horizontal(
                              left: Radius.circular(50),
                              right: Radius.circular(50))))),
                  onPressed: () async {
                    final cliente = await showSearch(
                        context: context,
                        delegate:
                            ClientSearchDelegate('Buscar Cliente', historial));
                    if (cliente != null) {
                      setState(() {
                        selectedCliente = cliente;
                        final int clienteExiste = historial.indexWhere(
                            (element) => element.nombre == cliente.nombre);
                        if (clienteExiste == -1) {
                          historial.insert(0, cliente);
                        }
                      });
                    } else {
                      setState(() {
                        selectedCliente = Cliente.empty();
                      });
                    }
                    if (selectedCliente.clienteId != 0) {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: Text('Confirmacion'),
                            content: Container(
                              child: Text(
                                  'Desea agregar al cliente ${selectedCliente.nombre}?'),
                            ),
                            actions: [
                              TextButton(
                                  onPressed: () async {
                                    await _userServices.postClientUsers(
                                        context,
                                        userSeleccionado.usuarioId.toString(),
                                        selectedCliente.clienteId.toString(),
                                        token);
                                    await getClientes(userSeleccionado, token);
                                  },
                                  child: Text('Agregar')),
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text('Cancelar')),
                            ],
                          );
                        },
                      );
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.5),
                    child: Text(
                      'Agregar cliente',
                      style: TextStyle(
                          color: Color.fromARGB(255, 52, 120, 62),
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Future<List<ClienteUsuario>> getClientes(Usuario user, String token) async {
    clientes =
        await _userServices.getClientUsers(user.usuarioId.toString(), token);
    setState(() {});
    return clientes;
  }
}
