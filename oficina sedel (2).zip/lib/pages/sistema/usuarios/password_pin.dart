import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/models/usuario.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/services/user_services.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';

import '../../../widgets/appbar.dart';
import '../../../widgets/drawer.dart';

class EditPwdPin extends StatefulWidget {
  const EditPwdPin({super.key});

  @override
  State<EditPwdPin> createState() => _EditPwdPinState();
}

class _EditPwdPinState extends State<EditPwdPin> {
  final _userServices = UserServices();
  final _passwordController = TextEditingController();
  final _pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _passwordController.dispose();
    _pinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Usuario userSeleccionado = context.read<OrdenProvider>().usuario;
    final token = context.read<OrdenProvider>().token;

    return Scaffold(
      appBar: AppBarDesign(titulo: 'Usuarios',),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Contraseña  "),
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          maxLines: 1,
                          label: 'Contraseña',
                          controller: _passwordController,
                          validator: (value) {
                            if (value!.length < 6 || value.length > 12) {
                              return 'Ingrese una contraseña valida';
                            }
                            return null;
                          },
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Reingrese  "),
                      SizedBox(
                        width: 35,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          label: 'Reingrese contraseña',
                          controller: _pinController,
                          maxLines: 1,
                          validator: (value) {
                            if (value != _passwordController.text) {
                              return 'Reingrese correctamente la contraseña';
                            }
                            return null;
                          },
                        ),
                      )
                    ],
                  ),
                  Spacer(),
                  BottomAppBar(
                      elevation: 0,
                      child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      if (_formKey.currentState!.validate()) {
                                        _userServices.patchPwd(
                                            context,
                                            userSeleccionado.usuarioId
                                                .toString(),
                                            _passwordController.text,
                                            token);
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Guardar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                              ])))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
