import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/widgets/drawer.dart';

class MenuDesktop extends StatefulWidget {
  const MenuDesktop({super.key});

  @override
  State<MenuDesktop> createState() => _MenuDesktopState();
}

class _MenuDesktopState extends State<MenuDesktop> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromARGB(255, 52, 120, 62),
          title: Text(
            'Menú',
            style: TextStyle(color: Colors.white),
          ),
        ),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: BotonesDrawer(),
        ),
        backgroundColor: Colors.white,
        body: Center(child: Container(child: Image.asset('images/logo.png'))),
        bottomNavigationBar: BottomAppBar(
            elevation: 0,
            child: IconButton.filledTonal(
                onPressed: () {
                  logout();
                },
                icon: Icon(Icons.logout))),
      ),
    );
  }

  void logout() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Cerrar sesion'),
          content: Text('Esta seguro de querer cerrar sesion?'),
          actions: [
            TextButton(
                onPressed: () {
                  router.pop();
                },
                child: Text('Cancelar')),
            TextButton(
                onPressed: () {
                  Provider.of<OrdenProvider>(context, listen: false)
                      .setToken('');
                  router.pushReplacement('/');
                },
                child: Text(
                  'Cerrar Sesion',
                  style: TextStyle(color: Colors.red),
                )),
          ],
        );
      },
    );
  }
}
