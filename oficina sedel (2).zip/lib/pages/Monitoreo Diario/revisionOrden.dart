import 'package:flutter/material.dart';

class RevisionOrdenPage extends StatefulWidget {
  const RevisionOrdenPage({super.key});

  @override
  State<RevisionOrdenPage> createState() => _RevisionOrdenPageState();
}

class _RevisionOrdenPageState extends State<RevisionOrdenPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: ElevatedButton(
        child: Text('data'),
        onPressed: () => Navigator.pop(context),
      )),
    );
  }
}
