import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/services/tecnico_services.dart';
import 'package:sedel_oficina_maqueta/services/ubicaciones_services.dart';
import 'package:sedel_oficina_maqueta/widgets/appbar.dart';
import 'package:sedel_oficina_maqueta/widgets/button_delegate.dart';
import 'package:sedel_oficina_maqueta/widgets/drawer.dart';
import 'package:intl/intl.dart';

import '../../models/cliente.dart';
import '../../models/tecnico.dart';
import '../../models/ubicacion.dart';

class MapaPage extends StatefulWidget {
  const MapaPage({super.key});

  @override
  State<MapaPage> createState() => _MapaPageState();
}

class _MapaPageState extends State<MapaPage> {
  Tecnico? selectedTecnico;
  Cliente? selectedCliente;
  DateTime selectedDate = DateTime.now();
  late String token = '';

  List<Tecnico> tecnicos = [];
  int tecnicoFiltro = 0;
  int clienteFiltro = 0;
  List<Ubicacion> ubicaciones = [];

  List<Ubicacion> ubicacionesFiltradas = [];
  final LatLng currentLocation = LatLng(-34.8927715, -56.1233649);
  late GoogleMapController mapController;
  Map<String, Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    cargarDatos();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (tecnicos.isEmpty) {
      loadTecnicos();
    }
  }

  cargarDatos() async {
    token = context.read<OrdenProvider>().token;
  }

  Future<void> loadTecnicos() async {
    final token = context.watch<OrdenProvider>().token;
    final loadedTecnicos = await TecnicoServices().getAllTecnicos(token);
    setState(() {
      tecnicos = loadedTecnicos;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBarDesign(
            titulo: 'Mapa',
          ),
          drawer: Drawer(
            child: BotonesDrawer(),
          ),
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      'Tecnico: ',
                      style: TextStyle(fontSize: 24),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    DropdownButton(
                      hint: Text('Tecnico'),
                      value: selectedTecnico,
                      onChanged: (value) {
                        setState(() {
                          selectedTecnico = value;
                          tecnicoFiltro = value!.tecnicoId;
                          // cargarUbicacion();
                          // cargarMarkers();
                        });
                      },
                      items: tecnicos.map((e) {
                        return DropdownMenuItem(
                          child: Text(e.nombre),
                          value: e,
                        );
                      }).toList(),
                    ),
                    SizedBox(
                      width: 30,
                    ),
                    Text(
                      'Cliente: ',
                      style: TextStyle(fontSize: 24),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    ButtonDelegate(colorSeleccionado: Colors.black),
                    Spacer(),
                    IconButton(
                        onPressed: () async {
                          final pickedDate = await showDatePicker(
                            initialDate: selectedDate,
                            firstDate: DateTime(2022),
                            lastDate: DateTime(2099),
                            context: context,
                          );

                          if (pickedDate != null &&
                              pickedDate != selectedDate) {
                            setState(() {
                              selectedDate = pickedDate;
                            });
                          }
                        },
                        icon: Icon(Icons.calendar_month)),
                    Text(
                      'Fecha: ',
                      style: TextStyle(fontSize: 24),
                    ),
                    Text(
                      DateFormat("E d, MMM", 'es').format(selectedDate),
                      style: TextStyle(fontSize: 22),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        width: MediaQuery.of(context).size.width / 1.35,
                        height: MediaQuery.of(context).size.height / 1.45,
                        child: Stack(
                          children: <Widget>[
                            GoogleMap(
                              initialCameraPosition: CameraPosition(
                                target: currentLocation,
                                zoom: 14.0,
                              ),
                              onMapCreated: (controller) {
                                mapController = controller;
                                // cargarUbicacion();
                                // cargarMarkers();
                              },
                              markers: _markers.values.toSet(),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Align(
                                alignment: Alignment.topRight,
                                child: Column(
                                  children: <Widget>[
                                    FloatingActionButton(
                                      onPressed: () async {
                                        ubicaciones =
                                            await UbicacionesServices()
                                                .getUbicaciones(
                                                    selectedTecnico!.tecnicoId,
                                                    selectedDate
                                                        .toIso8601String(),
                                                    selectedDate
                                                        .add(Duration(days: 1))
                                                        .toIso8601String(),
                                                    token);

                                        setState(() {
                                          cargarUbicacion();
                                          cargarMarkers();
                                        });
                                      },
                                      materialTapTargetSize:
                                          MaterialTapTargetSize.padded,
                                      backgroundColor: Colors.green,
                                      child: const Icon(
                                          Icons.format_list_bulleted_rounded,
                                          size: 36.0),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        )),
                    SizedBox(
                      width: 10,
                    ),
                    Card(
                      child: Container(
                          width: 300,
                          height: MediaQuery.of(context).size.height / 1.45,
                          child: ListView.builder(
                              itemCount: ubicacionesFiltradas.length,
                              itemBuilder: (context, i) {
                                var ubicacion = ubicacionesFiltradas[i];
                                return CheckboxListTile(
                                  title: Text(
                                    ubicacion.cliente.nombre,
                                    style: TextStyle(fontSize: 14),
                                  ),
                                  subtitle: Text(
                                      '${ubicacion.ordenTrabajoId} - ${DateFormat('HH:mm', 'es').format(ubicacion.fechaDate)}'),
                                  value: ubicacion.seleccionado,
                                  onChanged: (value) {
                                    ubicacion.seleccionado = value!;
                                    setState(() {
                                      cargarMarkers();
                                    });
                                  },
                                );
                              })),
                    )
                  ],
                ),
              ],
            ),
          )),
    );
  }

  addMarker(String id, LatLng location, String title, String snippet) {
    var marker = Marker(
        markerId: MarkerId(id),
        position: location,
        infoWindow: InfoWindow(title: title, snippet: snippet),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueCyan));
    _markers[id] = marker;
  }

  cargarMarkers() {
    _markers.clear();
    for (var ubicacion in ubicacionesFiltradas) {
      var coord = ubicacion.ubicacion?.split(',');

      if (ubicacion.seleccionado) {
        print('mostrando ${ubicacion.logId}');
        addMarker(
            ubicacion.logId.toString(),
            LatLng(double.parse(coord![0]), double.parse(coord[1])),
            'Cliente: ' + ubicacion.cliente.nombre,
            'Tecnico: ' + ubicacion.tecnico.nombre);
      }
    }
  }

  void cargarUbicacion() {
    ubicacionesFiltradas = ubicaciones
        .where((e) =>
            (clienteFiltro > 0 ? e.cliente.clienteId == clienteFiltro : true) &&
            (tecnicoFiltro > 0 ? e.tecnico.tecnicoId == tecnicoFiltro : true) &&
            e.ubicacion != '')
        .toList();
  }
}
