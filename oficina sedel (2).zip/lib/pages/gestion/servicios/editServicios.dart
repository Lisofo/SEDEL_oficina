import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/models/servicio.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/services/servicio_services.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_dropdown.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';

import '../../../widgets/appbar.dart';
import '../../../widgets/drawer.dart';

class EditServiciosPage extends StatefulWidget {
  const EditServiciosPage({super.key});

  @override
  State<EditServiciosPage> createState() => _EditServiciosPageState();
}

class _EditServiciosPageState extends State<EditServiciosPage> {
  final _servicioServices = ServiciosServices();
  final _codController = TextEditingController();
  final _descripcionController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  late List<TipoServicio> tipoServicios = [
    TipoServicio(tipoServicioId: 1, codTipoServicio: '1', descripcion: 'COMUN'),
    TipoServicio(
        tipoServicioId: 2, codTipoServicio: '2', descripcion: 'EVENTUAL'),
  ];
  TipoServicio? tipoServicioSeleccionado;
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _codController.dispose();
    _descripcionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    late Servicio servicioSeleccionado =
        context.watch<OrdenProvider>().servicio;
    final token = context.watch<OrdenProvider>().token;

    _codController.text = servicioSeleccionado.codServicio;
    _descripcionController.text = servicioSeleccionado.descripcion;

    tipoServicioSeleccionado = servicioSeleccionado.tipoServicio;
    late TipoServicio tipoServicioInicialSeleccionado = tipoServicios[0];

    if (tipoServicioSeleccionado!.tipoServicioId != 0) {
      tipoServicioInicialSeleccionado = tipoServicios.firstWhere(
          (tipoServicio) =>
              tipoServicio.tipoServicioId ==
              tipoServicioSeleccionado!.tipoServicioId);
    }

    return Scaffold(
      appBar: AppBarDesign(
        titulo: '',
      ),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Codigo  "),
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          controller: _codController,
                          maxLines: 1,
                          label: 'Codigo',
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Descripcion  "),
                      Container(
                        width: 800,
                        child: CustomTextFormField(
                          label: 'Descripcion',
                          controller: _descripcionController,
                          maxLines: 1,
                          maxLength: 100,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Tipo de servicio  "),
                      Container(
                        width: 300,
                        child: CustomDropdownFormMenu(
                          value: tipoServicioInicialSeleccionado,
                          hint: 'Seleccione cargo',
                          items: tipoServicios.map((e) {
                            return DropdownMenuItem(
                              value: e,
                              child: Text(e.descripcion),
                            );
                          }).toList(),
                          onChanged: (value) {
                            tipoServicioSeleccionado = value;
                          },
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  BottomAppBar(
                      elevation: 0,
                      child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      servicioSeleccionado.codServicio =
                                          _codController.text;
                                      servicioSeleccionado.descripcion =
                                          _descripcionController.text;
                                      servicioSeleccionado
                                              .tipoServicio.tipoServicioId =
                                          tipoServicioSeleccionado!
                                              .tipoServicioId;
                                      servicioSeleccionado.tipoServicioId =
                                          tipoServicioSeleccionado!
                                              .tipoServicioId;

                                      if (servicioSeleccionado.servicioId !=
                                          0) {
                                        _servicioServices.putServicios(context,
                                            servicioSeleccionado, token);
                                      } else {
                                        _servicioServices.postServicio(context,
                                            servicioSeleccionado, token);
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Guardar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                                SizedBox(
                                  width: 30,
                                ),
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      _servicioServices.deleteServicio(
                                          context, servicioSeleccionado, token);
                                      router.pop(context);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Eliminar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                              ])))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
