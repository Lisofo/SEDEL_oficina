// ignore_for_file: unused_local_variable, unused_element

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/models/tecnico.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/widgets/appbar.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_dropdown.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';
import 'package:sedel_oficina_maqueta/widgets/drawer.dart';
import 'package:intl/intl.dart';

class EditTecnicosPage extends StatefulWidget {
  const EditTecnicosPage({Key? key}) : super(key: key);

  @override
  State<EditTecnicosPage> createState() => _EditTecnicosPageState();
}

class _EditTecnicosPageState extends State<EditTecnicosPage> {
  late Tecnico tecnicoSeleccionado;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBarDesign(titulo: '',),
        drawer: Drawer(
          child: BotonesDrawer(),
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FotoYFirma(),
              Datos(),
            ],
          ),
        ),
        bottomNavigationBar: Botones(),
      ),
    );
  }
}

class Datos extends StatefulWidget {
  const Datos({
    super.key,
  });

  @override
  State<Datos> createState() => _DatosState();
}

class _DatosState extends State<Datos> {
  late Tecnico selectedTecnico = context.read<OrdenProvider>().tecnico;
  late List<Cargo> cargos = [
    Cargo(cargoId: 1, codCargo: '1', descripcion: 'Aprendiz'),
    Cargo(cargoId: 2, codCargo: '2', descripcion: 'Aplicador'),
    Cargo(cargoId: 3, codCargo: '3', descripcion: 'Supervisor'),
  ];
  Cargo? cargoSeleccionado;
  DateTime selectedDate = DateTime.now();
  // late String _setDate;
  late String dateTime;
  TextEditingController _dateController = TextEditingController();
  TextEditingController _dateHastaController = TextEditingController();
  final _nombreController = TextEditingController();
  final _docController = TextEditingController();
  final _codController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    _nombreController.text = selectedTecnico.nombre;
    _docController.text = selectedTecnico.documento;
    _codController.text = selectedTecnico.codTecnico;
    cargoSeleccionado = selectedTecnico.cargo;

    late Cargo cargoInicialSeleccionado = cargos[0];
    if (cargoSeleccionado!.cargoId != 0) {
      cargoInicialSeleccionado = cargos
          .firstWhere((cargo) => cargo.cargoId == cargoSeleccionado!.cargoId);
    }

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              tipoDato('Codigo', _codController),
              SizedBox(
                height: 20,
              ),
              tipoDato('Documento', _docController),
              SizedBox(
                height: 20,
              ),
              tipoDato('Nombre', _nombreController),
              SizedBox(
                height: 20,
              ),
              Row(
                children: [
                  Text('Cargo'),
                  SizedBox(
                    width: 15,
                  ),
                  Container(
                    width: 300,
                    child: CustomDropdownFormMenu(
                      value: cargoInicialSeleccionado,
                      hint: 'Seleccione cargo',
                      items: cargos.map((e) {
                        return DropdownMenuItem(
                          value: e,
                          child: Text(e.descripcion),
                        );
                      }).toList(),
                      onChanged: (value) {},
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Row tipoDato(String tipoDato, TextEditingController controller) {
    return Row(
      children: [
        Text("$tipoDato"),
        SizedBox(
          width: 15,
        ),
        Container(
          width: 300,
          child: CustomTextFormField(
            maxLines: 1,
            label: tipoDato,
            controller: controller,
          ),
        )
      ],
    );
  }

  Future<Null> _selectFechaIngreso(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(2015),
        lastDate: DateTime(2099));
    if (picked != null)
      setState(() {
        selectedDate = picked;
        _dateController.text = DateFormat.yMd().format(selectedDate);
      });
  }

  Future<Null> _selectFechaEgreso(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(2015),
        lastDate: DateTime(2099));
    if (picked != null)
      setState(() {
        selectedDate = picked;
        _dateHastaController.text = DateFormat.yMd().format(selectedDate);
      });
  }
}

class Botones extends StatelessWidget {
  const Botones({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
        elevation: 0,
        child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(Colors.white),
                      elevation: MaterialStatePropertyAll(10),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                          borderRadius: BorderRadius.horizontal(
                              left: Radius.circular(50),
                              right: Radius.circular(50))))),
                  onPressed: () {},
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.5),
                    child: Text(
                      'Guardar',
                      style: TextStyle(
                          color: Color.fromARGB(255, 52, 120, 62),
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  )),
              SizedBox(
                width: 30,
              ),
              ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(Colors.white),
                      elevation: MaterialStatePropertyAll(10),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                          borderRadius: BorderRadius.horizontal(
                              left: Radius.circular(50),
                              right: Radius.circular(50))))),
                  onPressed: () {},
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.5),
                    child: Text(
                      'Modificar',
                      style: TextStyle(
                          color: Color.fromARGB(255, 52, 120, 62),
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  )),
              SizedBox(
                width: 30,
              ),
              ElevatedButton(
                  style: ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(Colors.white),
                      elevation: MaterialStatePropertyAll(10),
                      shape: MaterialStatePropertyAll(RoundedRectangleBorder(
                          borderRadius: BorderRadius.horizontal(
                              left: Radius.circular(50),
                              right: Radius.circular(50))))),
                  onPressed: () {},
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.5),
                    child: Text(
                      'Eliminar',
                      style: TextStyle(
                          color: Color.fromARGB(255, 52, 120, 62),
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  )),
            ])));
  }
}

class FotoYFirma extends StatelessWidget {
  const FotoYFirma({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 300,
                child: Placeholder(),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                width: 300,
                child: Image.asset('images/Firmas_Tecnicos/ANDRES ABREU.JPG'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
