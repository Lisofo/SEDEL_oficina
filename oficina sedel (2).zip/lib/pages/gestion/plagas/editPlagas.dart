import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/models/plaga.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';

import '../../../services/plaga_services.dart';
import '../../../widgets/appbar.dart';
import '../../../widgets/drawer.dart';

class EditPlagasPage extends StatefulWidget {
  const EditPlagasPage({super.key});

  @override
  State<EditPlagasPage> createState() => _EditPlagasPageState();
}

class _EditPlagasPageState extends State<EditPlagasPage> {
  final _plagaServices = PlagaServices();
  final _codController = TextEditingController();
  final _descripcionController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _codController.dispose();
    _descripcionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    late Plaga plagaSeleccionada = context.watch<OrdenProvider>().plaga;
    final token = context.watch<OrdenProvider>().token;

    _codController.text = plagaSeleccionada.codPlaga;
    _descripcionController.text = plagaSeleccionada.descripcion;

    return Scaffold(
      appBar: AppBarDesign(
        titulo: '',
      ),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Codigo  "),
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          maxLines: 1,
                          label: 'Codigo',
                          controller: _codController,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Descripcion  "),
                      Container(
                        width: 800,
                        child: CustomTextFormField(
                          label: 'Descripcion',
                          maxLines: 1,
                          controller: _descripcionController,
                          maxLength: 100,
                        ),
                      )
                    ],
                  ),
                  Spacer(),
                  BottomAppBar(
                      elevation: 0,
                      child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      plagaSeleccionada.codPlaga =
                                          _codController.text;
                                      plagaSeleccionada.descripcion =
                                          _descripcionController.text;
                                      var status = _plagaServices.postPlaga(
                                          context, plagaSeleccionada, token);
                                      print(status);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Guardar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                                SizedBox(
                                  width: 30,
                                ),
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      plagaSeleccionada.codPlaga =
                                          _codController.text;
                                      plagaSeleccionada.descripcion =
                                          _descripcionController.text;
                                      _plagaServices.putPlaga(
                                          context, plagaSeleccionada, token);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Modificar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                                SizedBox(
                                  width: 30,
                                ),
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      _plagaServices.deletePlaga(
                                          context, plagaSeleccionada, token);
                                      router.pop(context);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Eliminar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                              ])))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
