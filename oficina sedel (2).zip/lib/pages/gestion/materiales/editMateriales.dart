import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/models/material.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/services/materiales_services.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';

import '../../../widgets/appbar.dart';
import '../../../widgets/drawer.dart';

class EditMaterialesPage extends StatefulWidget {
  const EditMaterialesPage({super.key});

  @override
  State<EditMaterialesPage> createState() => _EditMaterialesPageState();
}

class _EditMaterialesPageState extends State<EditMaterialesPage> {
  final _materialesServices = MaterialesServices();
  final _codMaterialController = TextEditingController();
  final _descripcionController = TextEditingController();
  final _dosisController = TextEditingController();
  final _unidadController = TextEditingController();
  final _favProbController = TextEditingController();
  final _enAppTecnicoController = TextEditingController();
  final _enUsoController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool filtro = false;
  bool filtro2 = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _codMaterialController.dispose();
    _descripcionController.dispose();
    _dosisController.dispose();
    _unidadController.dispose();
    _favProbController.dispose();
    _enAppTecnicoController.dispose();
    _enUsoController.dispose();
    super.dispose();
  }



  @override
  Widget build(BuildContext context) {
    late Materiales materialSeleccionado =
        context.watch<OrdenProvider>().materiales;
    final token = context.watch<OrdenProvider>().token;

    cargarValoresDeCampo(materialSeleccionado);
    return Scaffold(
      appBar: AppBarDesign(titulo: '',),
      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Codigo  "),
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          maxLines: 1,
                          label: 'Codigo',
                          controller: _codMaterialController,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Descripcion  "),
                      Container(
                        width: 500,
                        child: CustomTextFormField(
                          label: 'Descripcion',
                          maxLines: 1,
                          controller: _descripcionController,
                          maxLength: 100,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Dosis  "),
                      SizedBox(
                        width: 40,
                      ),
                      Container(
                        width: 800,
                        child: CustomTextFormField(
                          label: 'Dosis',
                          maxLines: 1,
                          controller: _dosisController,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Unidad  "),
                      SizedBox(
                        width: 35,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          label: 'Unidad',
                          maxLines: 1,
                          controller: _unidadController,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Fabricante/Proovdeor  "),
                      SizedBox(
                        width: 35,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          label: 'Fabricante/Proovdeor',
                          maxLines: 1,
                          controller: _favProbController,
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text('En App Tecnico'),
                      Switch(
                          activeColor: Color.fromARGB(255, 52, 120, 62),
                          value: materialSeleccionado.enAppTecnico == 'S',
                          onChanged: (value) {
                            setState(() {
                              filtro = value;
                              establecerValoresDeCampo(materialSeleccionado);
                              value
                                  ? materialSeleccionado.enAppTecnico = 'S'
                                  : materialSeleccionado.enAppTecnico = 'N';
                            });
                          }),
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text('En uso'),
                      Switch(
                          activeColor: Color.fromARGB(255, 52, 120, 62),
                          value: materialSeleccionado.enUso == 'S'
                              ? filtro2 = true
                              : filtro2 = false,
                          onChanged: (value) {
                            setState(() {
                              filtro2 = value;
                              value
                                  ? materialSeleccionado.enUso = 'S'
                                  : materialSeleccionado.enUso = 'N';
                              establecerValoresDeCampo(materialSeleccionado);
                            });
                          }),
                    ],
                  ),
                  Spacer(),
                  BottomAppBar(
                      elevation: 0,
                      child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      establecerValoresDeCampo(
                                          materialSeleccionado);

                                      if (materialSeleccionado.materialId !=
                                          0) {
                                        _materialesServices.putMaterial(context,
                                            materialSeleccionado, token);
                                      } else {
                                        _materialesServices.postMaterial(
                                            context,
                                            materialSeleccionado,
                                            token);
                                      }
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Guardar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                                SizedBox(
                                  width: 30,
                                ),
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      _materialesServices.deleteMaterial(
                                          context, materialSeleccionado, token);
                                      router.pop(context);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Eliminar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                              ])))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void cargarValoresDeCampo(Materiales materialSeleccionado) {
    _codMaterialController.text = materialSeleccionado.codMaterial;
    _descripcionController.text = materialSeleccionado.descripcion;
    _dosisController.text = materialSeleccionado.dosis;
    _unidadController.text = materialSeleccionado.unidad;
    _favProbController.text = materialSeleccionado.fabProv;
    _enAppTecnicoController.text = materialSeleccionado.enAppTecnico;
    _enUsoController.text = materialSeleccionado.enUso;
  }

  void establecerValoresDeCampo(Materiales materialSeleccionado) {
    materialSeleccionado.codMaterial = _codMaterialController.text;
    materialSeleccionado.descripcion = _descripcionController.text;
    materialSeleccionado.dosis = _dosisController.text;
    materialSeleccionado.unidad = _unidadController.text;
    materialSeleccionado.fabProv = _favProbController.text;
  }
}
