import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sedel_oficina_maqueta/config/router/app_router.dart';
import 'package:sedel_oficina_maqueta/models/tarea.dart';
import 'package:sedel_oficina_maqueta/provider/orden_provider.dart';
import 'package:sedel_oficina_maqueta/services/tareas_services.dart';
import 'package:sedel_oficina_maqueta/widgets/custom_form_field.dart';

import '../../../widgets/appbar.dart';
import '../../../widgets/drawer.dart';

class EditTareasPage extends StatefulWidget {
  const EditTareasPage({super.key});

  @override
  State<EditTareasPage> createState() => _EditTareasPageState();
}

class _EditTareasPageState extends State<EditTareasPage> {
  final _tareaServices = TareasServices();
  final _codController = TextEditingController();
  final _descripcionController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _codController.dispose();
    _descripcionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    late Tarea tareaSeleccionada = context.watch<OrdenProvider>().tarea;
    final token = context.watch<OrdenProvider>().token;

    _codController.text = tareaSeleccionada.codTarea;
    _descripcionController.text = tareaSeleccionada.descripcion;

    return Scaffold(
appBar: AppBarDesign(titulo: '',),      drawer: Drawer(
        child: BotonesDrawer(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Row(
                    children: [
                      Text("Codigo  "),
                      SizedBox(
                        width: 27,
                      ),
                      Container(
                        width: 300,
                        child: CustomTextFormField(
                          controller: _codController,
                          maxLines: 1,
                          label: 'Codigo',
                        ),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: [
                      Text("Descripcion  "),
                      Container(
                        width: 800,
                        child: CustomTextFormField(
                          label: 'Descripcion',
                          controller: _descripcionController,
                          maxLines: 1,
                          maxLength: 100,
                        ),
                      )
                    ],
                  ),
                  Spacer(),
                  BottomAppBar(
                      elevation: 0,
                      child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      tareaSeleccionada.codTarea =
                                          _codController.text;
                                      tareaSeleccionada.descripcion =
                                          _descripcionController.text;
                                      var status = _tareaServices.postTarea(
                                          context, tareaSeleccionada, token);
                                      print(status);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Guardar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                                SizedBox(
                                  width: 30,
                                ),
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      tareaSeleccionada.codTarea =
                                          _codController.text;
                                      tareaSeleccionada.descripcion =
                                          _descripcionController.text;
                                      _tareaServices.putTarea(
                                          context, tareaSeleccionada, token);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Modificar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                                SizedBox(
                                  width: 30,
                                ),
                                ElevatedButton(
                                    style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStatePropertyAll(
                                                Colors.white),
                                        elevation: MaterialStatePropertyAll(10),
                                        shape: MaterialStatePropertyAll(
                                            RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.horizontal(
                                                        left:
                                                            Radius.circular(50),
                                                        right: Radius.circular(
                                                            50))))),
                                    onPressed: () {
                                      _tareaServices.deleteTarea(
                                          context, tareaSeleccionada, token);
                                      router.pop(context);
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.5),
                                      child: Text(
                                        'Eliminar',
                                        style: TextStyle(
                                            color: Color.fromARGB(
                                                255, 52, 120, 62),
                                            fontWeight: FontWeight.bold,
                                            fontSize: 20),
                                      ),
                                    )),
                              ])))
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
