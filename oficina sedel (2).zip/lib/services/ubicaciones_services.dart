import 'package:dio/dio.dart';
import 'package:sedel_oficina_maqueta/config/config.dart';
import 'package:sedel_oficina_maqueta/models/ubicacion.dart';

class UbicacionesServices {
  final _dio = Dio();
  String apiUrl = Config.APIURL;
  late String apiLink = apiUrl + 'api/v1/ordenes/';

  Future getUbicaciones(
      int tecnicoId, String fechaDesde, String fechaHasta, String token) async {
    String link = apiLink +=
        'ubicaciones?tecnicoId=$tecnicoId&fechaDesde=$fechaDesde&fechaHasta=$fechaHasta';

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> ubicacionList = resp.data;

      return ubicacionList.map((obj) => Ubicacion.fromJson(obj)).toList();
    } catch (e) {
      print(e);
    }
  }
}
