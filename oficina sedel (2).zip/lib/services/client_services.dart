import 'package:dio/dio.dart';
import 'package:sedel_oficina_maqueta/config/config.dart';
import 'package:sedel_oficina_maqueta/models/cliente.dart';
import 'package:sedel_oficina_maqueta/models/servicios_clientes.dart';
import 'package:sedel_oficina_maqueta/models/tipo_clientes.dart';
import 'package:sedel_oficina_maqueta/models/usuarios_x_clientes.dart';
import 'package:flutter/material.dart';

class ClientServices {
  int? statusCode;
  List posts = [];
  List pagina = [];
  String apiUrl = Config.APIURL;

  int limit = 20;
  bool isLoadingMore = false;
  final _dio = Dio();

  static Future<void> showDialogs(BuildContext context, String errorMessage,
      bool doblePop, bool triplePop) async {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Mensaje'),
          content: Text(errorMessage),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (doblePop) {
                  Navigator.of(context).pop();
                }
                if (triplePop) {
                  Navigator.of(context).pop();
                }
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _mostrarError(BuildContext context, String mensaje) async {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Error'),
        content: Text(mensaje),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  Future<List<Cliente>> getClientes(String nombre, String codCliente,
      String? estado, String tecnicoId, String token) async {
    String link = apiUrl + 'api/v1/clientes/?offset=0&sort=nombre';
    bool yaTieneFiltro = true;
    if (nombre != '') {
      link += '&nombre=$nombre';
      yaTieneFiltro = true;
    }
    if (codCliente != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'codCliente=$codCliente';
      yaTieneFiltro = true;
    }
    if (estado != '' && estado != null) {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'estado=$estado';
      yaTieneFiltro = true;
    }
    if (tecnicoId != '' && tecnicoId != '0') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'tecnicoId=$tecnicoId';
      yaTieneFiltro = true;
    }

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> clienteList = resp.data;

      return clienteList.map((obj) => Cliente.fromJson(obj)).toList();
    } catch (e) {
      throw e;
    }
  }

  Future getUsuariosXCliente(String clienteId, String token) async {
    String link = apiUrl += 'api/v1/clientes/$clienteId/usuarios';
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List usuariosXClienteList = resp.data;

      return usuariosXClienteList
          .map((obj) => UsuariosXCliente.fromJson(obj))
          .toList();
    } catch (e) {
      print(e);
    }
  }

  Future getClienteServices(String clienteId, String token) async {
    String link = apiUrl += 'api/v1/clientes/$clienteId/servicios';

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List serviciosClientesList = resp.data;

      return serviciosClientesList
          .map((obj) => ServicioCliente.fromJson(obj))
          .toList();
    } catch (e) {
      print(e);
    }
  }

  Future putClienteServices(BuildContext context, String clienteId,
      ServicioCliente? servicio, String servicioId, String token) async {
    String link = apiUrl += 'api/v1/clientes/$clienteId/servicios/$servicioId';
    try {
      var headers = {'Authorization': token};
      final resp = await _dio.request(link,
          data: servicio?.toMap(),
          options: Options(method: 'PUT', headers: headers));

      statusCode = resp.statusCode;

      if (resp.statusCode == 200) {
        showDialogs(context, 'Servicio actualizado correctamente', true, false);
      } else {
        _mostrarError(
            context, 'Hubo un error al momento de editar el servicio');
      }
      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            await _mostrarError(context, errorMessages.join('\n'));
          } else {
            await _mostrarError(context, 'Error: ${e.response!.data}');
          }
        } else {
          await _mostrarError(context, 'Error: ${e.message}');
        }
      }
    }
  }

  Future postClienteServices(BuildContext context, String clienteId,
      ServicioCliente servicioCliente, String token) async {
    try {
      String link = apiUrl + 'api/v1/clientes/$clienteId/servicios';
      var headers = {'Authorization': token};
      var xx = servicioCliente.toMap();
      print('hola');
      final resp = await _dio.request(link,
          data: xx, options: Options(method: 'POST', headers: headers));

      servicioCliente.clienteServicioId = resp.data['clienteServicioId'];

      if (resp.statusCode == 201) {
        showDialogs(context, 'Servicio agregado correctamente', true, false);
      } else {
        _mostrarError(context, 'Hubo un error al momento de crear el servicio');
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            await _mostrarError(context, errorMessages.join('\n'));
          } else {
            await _mostrarError(context, 'Error: ${e.response!.data}');
          }
        } else {
          await _mostrarError(context, 'Error: ${e.message}');
        }
      }
    }
  }

  Future deleteClienteServices(BuildContext context, String clienteId,
      String servicioId, String token) async {
    try {
      String link = apiUrl;
      var headers = {'Authorization': token};

      final resp = await _dio.request(
          link + 'api/v1/clientes/$clienteId/servicios/$servicioId',
          options: Options(method: 'DELETE', headers: headers));
      if (resp.statusCode == 204) {
        await showDialogs(
            context, 'Servicio borrado correctamente', false, false);
      }
      return resp.statusCode;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            await showDialogs(context, errorMessages.join('\n'), false, false);
          } else {
            await showDialogs(
                context, 'Error: ${e.response!.data}', false, false);
          }
        } else {
          await showDialogs(context, 'Error: ${e.message}', false, false);
        }
      }
    }
  }

  Future getClientesDepartamentos(String token) async {
    String link = apiUrl += 'api/v1/clientes/departamentos';

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List departamentosClientesList = resp.data;

      return departamentosClientesList
          .map((obj) => Departamento.fromJson(obj))
          .toList();
    } catch (e) {
      print(e);
    }
  }

  Future getTipoClientes(String token) async {
    String link = apiUrl += 'api/v1/clientes/tipos';

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List tiposClientesList = resp.data;

      return tiposClientesList
          .map((obj) => TipoClientes.fromJson(obj))
          .toList();
    } catch (e) {
      print(e);
    }
  }

  Future putCliente(BuildContext context, Cliente cliente, String token) async {
    String link = apiUrl += 'api/v1/clientes/';
    var headers = {'Authorization': token};

    var map = cliente.toMap();

    try {
      final resp = await _dio.request(link += cliente.clienteId.toString(),
          data: map, options: Options(method: 'PUT', headers: headers));

      if (resp.statusCode == 200) {
        await showDialogs(
            context, 'Cliente actualizado correctamente', false, false);
      }
      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showDialogs(context, errorMessages.join('\n'), false, false);
          } else {
            showDialogs(context, 'Error: ${e.response!.data}', false, false);
          }
        } else {
          showDialogs(context, 'Error: ${e.message}', false, false);
        }
      }
    }
  }

  Future postCliente(
      BuildContext context, Cliente cliente, String token) async {
    try {
      String link = apiUrl += 'api/v1/clientes/';
      var headers = {'Authorization': token};

      final resp = await _dio.request(link,
          data: cliente.toMap(),
          options: Options(method: 'POST', headers: headers));

      cliente.clienteId = resp.data['clienteId'];

      if (resp.statusCode == 201) {
        showDialogs(context, 'Cliente creado correctamente', false, false);
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showDialogs(context, errorMessages.join('\n'), false, false);
          } else {
            showDialogs(context, 'Error: ${e.response!.data}', false, false);
          }
        } else {
          showDialogs(context, 'Error: ${e.message}', false, false);
        }
      }
    }
  }

  Future deleteCliente(
      BuildContext context, Cliente cliente, String token) async {
    try {
      String link = apiUrl + 'api/v1/clientes/';
      var headers = {'Authorization': token};

      final resp = await _dio.request(link += cliente.clienteId.toString(),
          options: Options(method: 'DELETE', headers: headers));
      if (resp.statusCode == 204) {
        showDialogs(context, 'Cambio hecho correctamente', true, true);
      }
      return resp.statusCode;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            _mostrarError(context, errorMessages.join('\n'));
          } else {
            _mostrarError(context, 'Error: ${e.response!.data}');
          }
        } else {
          _mostrarError(context, 'Error: ${e.message}');
        }
      }
    }
  }
}
