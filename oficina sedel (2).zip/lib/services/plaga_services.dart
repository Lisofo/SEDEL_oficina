import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:sedel_oficina_maqueta/config/config.dart';
import 'package:sedel_oficina_maqueta/models/plaga.dart';

class PlagaServices {
  final _dio = Dio();
  String apiUrl = Config.APIURL;
  late String apiLink = apiUrl + 'api/v1/plagas/';

  static void showErrorDialog(BuildContext context, String errorMessage) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Mensaje'),
          content: Text(errorMessage),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  Future getPlagaById(BuildContext context, String id, String token) async {
    String link = apiLink;
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link += '$id',
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );

      final Plaga plaga = Plaga.fromJson(resp.data);

      return plaga;
    } catch (e) {
      print(e);
    }
  }

  Future getPlagas(BuildContext context, String descripcion, String codPlaga,
      String token) async {
    String link = apiLink;
    bool yaTieneFiltro = false;
    if (descripcion != '') {
      link += '?descripcion=$descripcion';
      yaTieneFiltro = true;
    }
    if (codPlaga != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'codPlaga=$codPlaga';
      yaTieneFiltro = true;
    }

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> plagaList = resp.data;

      return plagaList.map((obj) => Plaga.fromJson(obj)).toList();
    } catch (e) {
      if (e is DioException) {
        if (e.type == DioExceptionType.connectionError) {
          showErrorDialog(context, 'Error: ${e.message}');
        } else {
          print('error');
        }
      }
    }
  }

  Future putPlaga(BuildContext context, Plaga plaga, String token) async {
    try {
      String link = apiLink;
      var headers = {'Authorization': token};

      final resp = await _dio.request(link += plaga.plagaId.toString(),
          data: plaga.toMap(),
          options: Options(method: 'PUT', headers: headers));

      if (resp.statusCode == 200) {
        showErrorDialog(context, 'Plaga actualizada correctamente');
      }
      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showErrorDialog(context, errorMessages.join('\n'));
          } else {
            showErrorDialog(context, 'Error: ${e.response!.data}');
          }
        } else {
          showErrorDialog(context, 'Error: ${e.message}');
        }
      }
    }
  }

  Future postPlaga(BuildContext context, Plaga plaga, String token) async {
    try {
      String link = apiLink;
      var headers = {'Authorization': token};

      final resp = await _dio.request(link,
          data: plaga.toMap(),
          options: Options(method: 'POST', headers: headers));

      plaga.plagaId = resp.data['plagaId'];

      if (resp.statusCode == 201) {
        showErrorDialog(context, 'Plaga creada correctamente');
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showErrorDialog(context, errorMessages.join('\n'));
          } else {
            showErrorDialog(context, 'Error: ${e.response!.data}');
          }
        } else {
          showErrorDialog(context, 'Error: ${e.message}');
        }
      } 
    }
  }

  Future deletePlaga(BuildContext context, Plaga plaga, String token) async {
    try {
      String link = apiLink;
      var headers = {'Authorization': token};

      final resp = await _dio.request(link += plaga.plagaId.toString(),
          options: Options(method: 'DELETE', headers: headers));
      if (resp.statusCode == 204) {
        showErrorDialog(context, 'Cambio hecho correctamente');
      }
      return resp.statusCode;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showErrorDialog(context, errorMessages.join('\n'));
          } else {
            showErrorDialog(context, 'Error: ${e.response!.data}');
          }
        } else {
          showErrorDialog(context, 'Error: ${e.message}');
        }
      }
    }
  }

  // Future<Plaga> GuardarPlaga(Plaga plaga, String token) async {
  //   Dio dio = Dio();
  //   var headers = {'Authorization': token};
  //   Response resp = await dio.post( data: plaga.toMap(),
  //     options: Options(headers: headers),
  //     apiLink);

  //   Map<String, dynamic> data = resp.data;

  //   Plaga plaga = Plaga.fromJson(data);

  //   return plaga;
  // }
}
