import 'package:dio/dio.dart';
import 'package:sedel_oficina_maqueta/config/config.dart';
import 'package:sedel_oficina_maqueta/models/tecnico.dart';

class TecnicoServices {
  final _dio = Dio();

  String apiUrl = Config.APIURL;
  late String apiLink = apiUrl + 'api/v1/tecnicos/';

  Future getTecnicoById(String id, String token) async {
    String link = apiLink;
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link += '$id',
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );

      final Tecnico tecnico = Tecnico.fromJson(resp.data);

      return tecnico;
    } catch (e) {
      print(e);
    }
  }

  Future getTecnicos(
      String documento, String codTecnico, String nombre, String token) async {
    bool yaTieneFiltro = false;
    var link = apiLink;
    if (documento != '') {
      link += '?documento=$documento';
      yaTieneFiltro = true;
    }
    if (codTecnico != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'codTecnico=$codTecnico';
      yaTieneFiltro = true;
    }
    if (nombre != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'nombre=$nombre';
      yaTieneFiltro = true;
    }
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> tecnicoList = resp.data;

      return tecnicoList.map((obj) => Tecnico.fromJson(obj)).toList();
    } catch (e) {
      print(e);
    }
  }

  Future getAllTecnicos(String token) async {
    var link = apiLink;
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );
      final List<dynamic> tecnicoList = resp.data;

      return tecnicoList.map((obj) => Tecnico.fromJson(obj)).toList();
    } catch (e) {
      print(e);

      throw e;
    }
  }
}
