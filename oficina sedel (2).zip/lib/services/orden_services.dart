import 'package:dio/dio.dart';
import 'package:sedel_oficina_maqueta/config/config.dart';
import 'package:sedel_oficina_maqueta/models/orden.dart';
import 'package:flutter/material.dart';

class OrdenServices {
  String apiUrl = Config.APIURL;
  late String apiLink = apiUrl + 'api/v1/ordenes/';
  final _dio = Dio();

  static Future<void> showDialogs(BuildContext context, String errorMessage,
      bool doblePop, bool triplePop) async {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Mensaje'),
          content: Text(errorMessage),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (doblePop) {
                  Navigator.of(context).pop();
                }
                if (triplePop) {
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _mostrarError(BuildContext context, String mensaje) async {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Error'),
        content: Text(mensaje),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  Future getOrdenByid(String id, String token) async {
    String link = apiLink;
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link += '$id',
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );

      final List<dynamic> ordenList = resp.data;

      return ordenList.map((obj) => Orden.fromJson(obj)).toList();
    } catch (e) {
      print(e);
    }
  }

  Future getOrden(String clienteId, String tecnicoId, String desde,
      String hasta, String ordenTrabajoId, String token) async {
    bool yaTieneFiltro = false;
    String link = apiLink;
    String linkFiltrado = link += '?sort=fechaDesde&limit=1000';
    yaTieneFiltro = true;
    if (clienteId != '0' && clienteId != '') {
      linkFiltrado += '&clienteId=$clienteId';
      yaTieneFiltro = true;
    }
    if (tecnicoId != '' && tecnicoId != '0') {
      yaTieneFiltro ? linkFiltrado += '&' : linkFiltrado += '?';
      linkFiltrado += 'tecnicoId=$tecnicoId';
      yaTieneFiltro = true;
    }
    if (desde != '') {
      yaTieneFiltro ? linkFiltrado += '&' : linkFiltrado += '?';
      linkFiltrado += 'fechaDesde=$desde';
      yaTieneFiltro = true;
    }
    if (hasta != '') {
      yaTieneFiltro ? linkFiltrado += '&' : linkFiltrado += '?';
      linkFiltrado += 'fechaHasta=$hasta';
      yaTieneFiltro = true;
    }
    if (ordenTrabajoId != '' && ordenTrabajoId != '0') {
      yaTieneFiltro ? linkFiltrado += '&' : linkFiltrado += '?';
      linkFiltrado += 'ordenTrabajoId=$ordenTrabajoId';
      yaTieneFiltro = true;
    }
    print(linkFiltrado);
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        linkFiltrado,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );

      final List<dynamic> ordenList = resp.data;
      var retorno = ordenList.map((obj) => Orden.fromJson(obj)).toList();
      print(retorno.length);
      return retorno;
    } on DioException catch (e) {
      print(e.error);
      print(e.response);
    }
  }

  Future patchOrden(BuildContext context, Orden orden, String estado,
      int ubicacionId, String token) async {
    String link = apiLink;
    link += '${orden.ordenTrabajoId.toString()}';

    try {
      var headers = {'Authorization': token};
      var data = ({"estado": estado, "ubicacionId": ubicacionId});
      var resp = await _dio.request(link,
          options: Options(
            method: 'PATCH',
            headers: headers,
          ),
          data: data);

      if (resp.statusCode == 200) {
        orden.estado = estado;
      } else {
        _mostrarError(
            context, 'Hubo un error al momento de cambiar el servicio');
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            await _mostrarError(context, errorMessages.join('\n'));
          } else {
            await _mostrarError(context, 'Error: ${e.response!.data}');
          }
        } else {
          await _mostrarError(context, 'Error: ${e.message}');
        }
      }
    }
  }

  Future cambiarTecnicoDeLaOrden(
      BuildContext context, Orden orden, int tecnicoId, String token) async {
    String link = apiLink;
    link += '${orden.ordenTrabajoId.toString()}';

    try {
      var headers = {'Authorization': token};
      var data = ({"tecnicoId": tecnicoId});
      var resp = await _dio.request(link,
          options: Options(
            method: 'PUT',
            headers: headers,
          ),
          data: data);

      if (resp.statusCode == 200) {
        orden.tecnico.tecnicoId = tecnicoId;
      } else {
        _mostrarError(
            context, 'Hubo un error al momento de cambiar el tecnico');
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            await _mostrarError(context, errorMessages.join('\n'));
          } else {
            await _mostrarError(context, 'Error: ${e.response!.data}');
          }
        } else {
          await _mostrarError(context, 'Error: ${e.message}');
        }
      }
    }
  }
}
