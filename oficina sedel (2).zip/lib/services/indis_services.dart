import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:sedel_oficina_maqueta/config/config.dart';
import 'package:sedel_oficina_maqueta/models/indisponibilidades.dart';

class IndisponibilidadServices {
  final _dio = Dio();
  String apiUrl = Config.APIURL;
  late String apiLink = apiUrl + 'api/v1/indisponibilidades/';

  static void showErrorDialog(BuildContext context, String errorMessage) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Mensaje'),
          content: Text(errorMessage),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  Future getIndisponibilidadById(
      BuildContext context, String id, String token) async {
    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        apiLink += '$id',
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );

      final Indisponibilidad inidisponibilidad =
          Indisponibilidad.fromJson(resp.data);

      return inidisponibilidad;
    } catch (e) {
      print(e);
    }
  }

  Future getIndisponibilidad(
      BuildContext context,
      String comentario,
      String desde,
      String hasta,
      String tipoIndisponibilidadId,
      String tecnicoId,
      String clienteId,
      String token) async {
    bool yaTieneFiltro = false;
    var link = apiLink;
    if (comentario != '') {
      link += '?comentario=$comentario';
      yaTieneFiltro = true;
    }
    if (desde != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'desde=$desde';
      yaTieneFiltro = true;
    }
    if (hasta != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'hasta=$hasta';
      yaTieneFiltro = true;
    }
    if (tipoIndisponibilidadId != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'hasta=$hasta';
      yaTieneFiltro = true;
    }
    if (tecnicoId != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'tecnicoId=$tecnicoId';
      yaTieneFiltro = true;
    }
    if (clienteId != '') {
      yaTieneFiltro ? link += '&' : link += '?';
      link += 'clienteId=$clienteId';
      yaTieneFiltro = true;
    }

    try {
      var headers = {'Authorization': token};
      var resp = await _dio.request(
        link,
        options: Options(
          method: 'GET',
          headers: headers,
        ),
      );

      final List<dynamic> indisList = resp.data;

      return indisList.map((obj) => Indisponibilidad.fromJson(obj)).toList();
    } catch (e) {
      if (e is DioException) {
        if (e.type == DioExceptionType.connectionError) {
          showErrorDialog(context, 'Error: ${e.message}');
        } else {
          print(e);
        }
      }
    }
  }

  Future putIndisponibilidad(BuildContext context,
      Indisponibilidad indisponibilidad, String token) async {
    try {
      String link = apiLink;
      var headers = {'Authorization': token};

      final resp = await _dio.request(
          link += indisponibilidad.indisponibilidadId.toString(),
          data: indisponibilidad.toMap(),
          options: Options(method: 'PUT', headers: headers));

      if (resp.statusCode == 200) {
        showErrorDialog(context, 'Indisponibilidad actualizada correctamente');
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showErrorDialog(context, errorMessages.join('\n'));
          } else {
            showErrorDialog(context, 'Error: ${e.response!.data}');
          }
        } else {
          showErrorDialog(context, 'Error: ${e.message}');
        }
      }
    }
  }

  Future postIndisponibilidad(BuildContext context,
      Indisponibilidad indisponibilidad, String token) async {
    try {
      String link = apiLink;
      var headers = {'Authorization': token};

      final resp = await _dio.request(link,
          data: indisponibilidad.toMap(),
          options: Options(method: 'POST', headers: headers));

      indisponibilidad.indisponibilidadId = resp.data['indisponibilidadId'];

      if (resp.statusCode == 201) {
        showErrorDialog(context, 'Indisponibilidad creada correctamente');
      }

      return;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showErrorDialog(context, errorMessages.join('\n'));
          } else {
            showErrorDialog(context, 'Error: ${e.response!.data}');
          }
        } else {
          showErrorDialog(context, 'Error: ${e.message}');
        }
      } else {
        showErrorDialog(context, 'Cambio hecho correctamente');
      }
    }
  }

  Future deleteindisponibilidad(BuildContext context,
      Indisponibilidad indisponibilidad, String token) async {
    try {
      String link = apiLink;
      var headers = {'Authorization': token};

      final resp = await _dio.request(
          link += indisponibilidad.indisponibilidadId.toString(),
          options: Options(method: 'DELETE', headers: headers));

      if (resp.statusCode == 204) {
        showErrorDialog(context, 'Cambio hecho correctamente');
      }
      return resp.statusCode;
    } catch (e) {
      if (e is DioException) {
        if (e.response != null) {
          final responseData = e.response!.data;
          if (responseData != null) {
            final errors = responseData['errors'] as List<dynamic>;
            final errorMessages = errors.map((error) {
              return "Error: ${error['message']}";
            }).toList();
            showErrorDialog(context, errorMessages.join('\n'));
          } else {
            showErrorDialog(context, 'Error: ${e.response!.data}');
          }
        } else {
          showErrorDialog(context, 'Error: ${e.message}');
        }
      }
    }
  }
}
